// deploy/pendingVpsStore.js — bridges /vps add's slash command options
// (non-secret: name/host/port/username/auth-method) to the modal that
// collects the actual secret, the same pattern as pendingDeployStore.js.
// Kept as a separate store since it holds a different shape and has a
// much shorter natural lifetime (one modal round-trip).

const crypto = require('node:crypto');

const TTL_MS = 5 * 60 * 1000;
const store = new Map();

function create(data) {
  const token = crypto.randomBytes(6).toString('hex');
  store.set(token, { ...data, createdAt: Date.now() });
  return token;
}

function get(token) {
  const entry = store.get(token);
  if (!entry) return null;
  if (Date.now() - entry.createdAt > TTL_MS) {
    store.delete(token);
    return null;
  }
  return entry;
}

function remove(token) {
  store.delete(token);
}

setInterval(() => {
  const now = Date.now();
  for (const [token, entry] of store.entries()) {
    if (now - entry.createdAt > TTL_MS) store.delete(token);
  }
}, 60 * 1000).unref();

module.exports = { create, get, remove };
