// deploy/uninstallRunner.js — build brief section 4: "/uninstall a
// previously deployed panel... destructive, so confirm first." Teardown
// has to match how each panel was actually installed (see lib/*/install.sh):
// docker-mode panels get `docker compose down -v` against the compose file
// install.sh wrote into RESULT_COMPOSE_DIR; Reviactyl (the one native
// panel today) gets its systemd service, nginx vhost, database, and
// scoped system user torn down individually since there's no compose
// stack to reach for.

function quote(value) {
  return `'${String(value).replace(/'/g, "'\\''")}'`;
}

/**
 * @param {string} panelId
 * @param {'docker'|'native'|'native-hybrid'} mode
 * @param {string} installDir  RESULT_COMPOSE_DIR or RESULT_INSTALL_DIR from the original deploy
 * @returns {{command: string, verified: boolean}} verified=false means this
 *   is a best-effort fallback, not a teardown path this library actually
 *   documents/tested — surfaced to the user so they know to double check.
 */
function buildUninstallCommand(panelId, mode, installDir) {
  const dir = quote(installDir);

  if (mode === 'docker') {
    return {
      command: `docker compose -f ${dir}/docker-compose.yml down -v --remove-orphans && rm -rf ${dir}`,
      verified: true,
    };
  }

  if (panelId === 'reviactyl') {
    return {
      command: [
        'systemctl disable --now reviq.service || true',
        'rm -f /etc/systemd/system/reviq.service',
        'systemctl daemon-reload',
        'rm -f /etc/nginx/sites-enabled/reviactyl.conf /etc/nginx/sites-available/reviactyl.conf',
        'systemctl reload nginx || true',
        `mariadb -e "DROP DATABASE IF EXISTS reviactyl; DROP USER IF EXISTS 'reviactyl'@'127.0.0.1';" || true`,
        'crontab -u reviactyl -r 2>/dev/null || true',
        'userdel -r reviactyl 2>/dev/null || true',
        `rm -rf ${dir}`,
      ].join(' && '),
      verified: true,
    };
  }

  // No documented teardown for this panel/mode combination yet — remove
  // the install directory only, and say so plainly rather than guessing
  // at service names that might not exist.
  return { command: `rm -rf ${dir}`, verified: false };
}

module.exports = { buildUninstallCommand };
