// deploy/deployRunner.js — the only place that understands the
// lib/*/install.sh invocation contract (build brief section 6):
//
//   PANEL_ID: <id>              first line, before any real work
//   STEP: <text>                progress, for message edits
//   OK: <text>                  sub-step finished
//   WARN: <text>                non-fatal caveat
//   ERR: <text>  (stderr)       fatal reason, final line on failure
//   DONE: <text>                success marker
//   RESULT_<FIELD>: <value>     one or more, after DONE
//
// Exit codes: 0 success, 1 real failure, 2 bad input (bot-side bug — the
// option validation in commands/deployment/deploy.js should make this
// unreachable), 3 = panel refuses to run (MythicalDash's verification
// guard today, potentially others later).
//
// The PANEL_ID check exists specifically to catch a /deploy routing bug
// (build brief section 6): if the panel-choice -> script-path mapping
// ever calls the wrong install.sh, that would otherwise silently succeed
// and hand back a *working panel that isn't the one the user asked for*.
// On any mismatch this hard-aborts the executor — it does not let the
// script continue to migrations/admin-creation/anything else.

const fs = require('node:fs');
const path = require('node:path');
const config = require('../config/config');
const logger = require('../utils/logger').create('deployRunner');

const RESULT_LINE_RE = /^RESULT_([A-Z0-9_]+):\s*(.*)$/;
const PANEL_ID_RE = /^PANEL_ID:\s*(.*)$/;

/**
 * @param {object} opts
 * @param {import('../executors/executor')} opts.executor  an already-constructed local/remote executor
 * @param {string} opts.panelId
 * @param {string[]} opts.argv
 * @param {number} opts.deploymentId  used only to name the log file
 * @param {(update: {type: string, text?: string}) => void} [opts.onProgress]
 *   Called for every STEP/OK/WARN as it arrives, for the caller's
 *   throttled Discord message-edit loop.
 */
async function runInstall({ executor, panelId, argv, deploymentId, onProgress = () => {} }) {
  const controller = new AbortController();
  const timeoutMs = executor.type === 'local' ? config.execution.localTimeoutMs : config.execution.remoteTimeoutMs;

  const rawLines = [];
  const warnings = [];
  const errLines = [];
  const result = {};
  let panelIdConfirmed = false;
  let panelIdMismatch = false;
  let sawDone = false;

  const onLine = ({ stream, line }) => {
    if (line === '') return;

    // Redact secret-shaped RESULT_ values (admin password, any future
    // token/secret field) before they ever touch the persisted log file
    // that /logs serves back — the one-time reveal button is pointless if
    // the same value sits in plaintext in a log anyone with /logs access
    // could read afterward. The real value is still captured into
    // `result` below from this same, unredacted `line`.
    const resultLineMatch = RESULT_LINE_RE.exec(line);
    const isSecretResult = resultLineMatch && /PASSWORD|TOKEN|SECRET/i.test(resultLineMatch[1]);
    rawLines.push(`[${stream}] ${isSecretResult ? `RESULT_${resultLineMatch[1]}: [REDACTED]` : line}`);

    if (!panelIdConfirmed) {
      const m = PANEL_ID_RE.exec(line);
      if (m) {
        panelIdConfirmed = true;
        if (m[1].trim() !== panelId) {
          panelIdMismatch = true;
          rawLines.push(
            `[runner] ABORT: script announced PANEL_ID="${m[1].trim()}" but "${panelId}" was requested — ` +
              `this is a /deploy routing bug, not a script failure. Hard-aborting before any further steps run.`,
          );
          onProgress({ type: 'panel_id_mismatch', text: m[1].trim() });
          controller.abort();
          return;
        }
      }
    }

    if (line.startsWith('STEP: ')) {
      onProgress({ type: 'step', text: line.slice('STEP: '.length) });
      return;
    }
    if (line.startsWith('OK: ')) {
      onProgress({ type: 'ok', text: line.slice('OK: '.length) });
      return;
    }
    if (line.startsWith('WARN: ')) {
      const text = line.slice('WARN: '.length);
      warnings.push(text);
      onProgress({ type: 'warn', text });
      return;
    }
    if (line.startsWith('ERR: ')) {
      errLines.push(line.slice('ERR: '.length));
      return;
    }
    if (line.startsWith('DONE: ')) {
      sawDone = true;
      onProgress({ type: 'done', text: line.slice('DONE: '.length) });
      return;
    }
    const resultMatch = RESULT_LINE_RE.exec(line);
    if (resultMatch) {
      result[resultMatch[1]] = resultMatch[2];
    }
  };

  await executor.prepare(panelId);

  let exitCode;
  try {
    ({ exitCode } = await executor.run(panelId, argv, {
      signal: controller.signal,
      timeoutMs,
      onLine,
    }));
  } finally {
    await executor.cleanup();
  }

  const logFile = path.join(config.storage.logDir, `deployment-${deploymentId}.log`);
  fs.writeFileSync(logFile, rawLines.join('\n'), 'utf8');

  if (panelIdMismatch) {
    return {
      outcome: 'routing_bug',
      exitCode: exitCode ?? -1,
      logFile,
      message:
        'The installer reported a different panel than the one requested. This is a bot-side routing bug, ' +
        'not a deployment failure — nothing further was run, and no panel was installed or modified.',
    };
  }

  if (exitCode === 0 && sawDone) {
    return { outcome: 'success', exitCode, logFile, result, warnings };
  }

  if (exitCode === 3) {
    return {
      outcome: 'blocked',
      exitCode,
      logFile,
      message: errLines[errLines.length - 1] || 'This panel refuses to run pending verification.',
    };
  }

  if (exitCode === 2) {
    logger.error(`panel ${panelId} rejected its own argv as bad input — this should not happen`, { argv });
    return {
      outcome: 'bad_input',
      exitCode,
      logFile,
      message:
        errLines[errLines.length - 1] ||
        'The installer rejected its input flags. This indicates a mismatch between the bot and lib/panels.json.',
    };
  }

  return {
    outcome: 'failed',
    exitCode: exitCode ?? -1,
    logFile,
    message: errLines[errLines.length - 1] || 'The installer exited with an error and no ERR: reason was captured.',
    warnings,
  };
}

module.exports = { runInstall };
