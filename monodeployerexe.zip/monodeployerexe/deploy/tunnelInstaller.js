// deploy/tunnelInstaller.js — build brief section 7. The token already
// encodes the tunnel the user configured in Cloudflare Zero Trust, so all
// the bot does is make sure `cloudflared` exists on the target and hand
// it the token via `cloudflared service install <TOKEN>`.
//
// This is deliberately NOT part of lib/<panel>/install.sh — it's an
// orthogonal exposure-layer step that can be run standalone via /tunnel
// independently of a deploy, per section 7 ("let the user add a tunnel
// later via /tunnel without redeploying anything").

const config = require('../config/config');
const validators = require('../utils/validators');

const INSTALL_IF_MISSING = [
  'if ! command -v cloudflared >/dev/null 2>&1; then',
  '  (curl -fsSL https://pkg.cloudflare.com/cloudflared.deb -o /tmp/cloudflared.deb && dpkg -i /tmp/cloudflared.deb) ||',
  '  (curl -fsSL -o /usr/local/bin/cloudflared',
  '     https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 &&',
  '   chmod +x /usr/local/bin/cloudflared);',
  'fi',
].join(' ');

/**
 * @param {import('../executors/executor')} executor  already-usable local or remote executor
 * @param {string} token  Cloudflare Tunnel token, plaintext — never logged, never echoed back
 * @param {(update: {stream: string, line: string}) => void} [onLine]
 */
async function installTunnel(executor, token, { onLine, timeoutMs } = {}) {
  const quotedToken = `'${token.replace(/'/g, `'\\''`)}'`;
  const command = `${INSTALL_IF_MISSING} cloudflared service install ${quotedToken}`;

  // Defense in depth: even though cloudflared's own output shouldn't echo
  // the token back, scrub it out of anything that reaches the caller
  // before it could ever be turned into a Discord message.
  const safeOnLine = onLine
    ? (update) => onLine({ ...update, line: validators.scrubSecrets(update.line, [token]) })
    : undefined;

  return executor.runRaw(command, {
    onLine: safeOnLine,
    timeoutMs: timeoutMs ?? config.execution.localTimeoutMs,
  });
}

module.exports = { installTunnel };
