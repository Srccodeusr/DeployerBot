// deploy/pendingTunnelStore.js — bridges /tunnel add's deployment-id
// option to the modal that collects the Cloudflare token itself, same
// pattern as pendingVpsStore.js.

const crypto = require('node:crypto');

const TTL_MS = 5 * 60 * 1000;
const store = new Map();

function create(data) {
  const token = crypto.randomBytes(6).toString('hex');
  store.set(token, { ...data, createdAt: Date.now() });
  return token;
}

function get(token) {
  const entry = store.get(token);
  if (!entry) return null;
  if (Date.now() - entry.createdAt > TTL_MS) {
    store.delete(token);
    return null;
  }
  return entry;
}

function remove(token) {
  store.delete(token);
}

setInterval(() => {
  const now = Date.now();
  for (const [tok, entry] of store.entries()) {
    if (now - entry.createdAt > TTL_MS) store.delete(tok);
  }
}, 60 * 1000).unref();

module.exports = { create, get, remove };
