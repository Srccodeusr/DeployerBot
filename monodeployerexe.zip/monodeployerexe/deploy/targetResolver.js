// deploy/targetResolver.js — every command that eventually needs an
// executor (deploy, uninstall, tunnel, status) resolves one the same way:
// 'local' needs nothing extra; 'remote' needs a saved VPS profile
// decrypted just-in-time. Centralized so decryption happens in exactly
// one place rather than being copy-pasted into four command files.

const { createExecutor } = require('../executors/executor');
const vpsProfiles = require('../database/models/vpsProfiles');

/**
 * @param {'local'|'remote'} targetType
 * @param {number|null} vpsProfileId
 * @returns {{executor: import('../executors/executor'), label: string}}
 */
function resolve(targetType, vpsProfileId) {
  if (targetType === 'local') {
    return { executor: createExecutor('local'), label: 'this machine' };
  }
  const profile = vpsProfiles.findById(vpsProfileId);
  if (!profile) throw new Error('saved VPS profile no longer exists (it may have been removed)');
  const creds = vpsProfiles.getDecryptedCredentials(profile);
  return { executor: createExecutor('remote', creds), label: `${profile.name} (${profile.username}@${profile.host})` };
}

module.exports = { resolve };
