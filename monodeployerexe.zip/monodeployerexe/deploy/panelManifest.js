// deploy/panelManifest.js — lib/panels.json is the single source of truth
// for what's deployable (build brief section 6). /panels and /deploy's
// option validation both read through this module rather than
// re-hardcoding the panel list, so an update to panels.json (e.g. flipping
// MythicalDash from blocked_pending_verification to ready once its compose
// file is verified) doesn't require touching command code.

const fs = require('node:fs');
const path = require('node:path');

const MANIFEST_PATH = path.join(__dirname, '..', 'lib', 'panels.json');

function load() {
  const raw = fs.readFileSync(MANIFEST_PATH, 'utf8');
  const parsed = JSON.parse(raw);
  return parsed.panels;
}

/** Fresh read each call — panels.json is expected to change over the
 * bot's lifetime (MythicalDash's status flip is the documented example)
 * and a restart shouldn't be required to pick that up... but since this
 * is a sync fs.readFileSync on a small file, cost is negligible either
 * way. */
function all() {
  return load();
}

function byId(panelId) {
  return all().find((p) => p.id === panelId) ?? null;
}

/** Panels that /deploy is allowed to offer as a selectable option.
 * Build brief section 4: "never offer a blocked_pending_verification or
 * unlisted panel as a selectable option." Airlink (`status: external`) is
 * deliberately excluded too — it's real, but section 6 says to point
 * users at Airlink's own installer rather than routing it through
 * lib/<panel>/install.sh, so it doesn't belong in this bot's /deploy flow. */
function deployable() {
  return all().filter((p) => p.status === 'ready' || p.status === 'partial');
}

/** Everything /panels should list, including external/blocked entries —
 * those are shown with their caveat, just not made selectable in /deploy. */
function listable() {
  return all();
}

/** Optionally narrowed by a guild's /admin panel allow-list. `null`
 * enabledIds means "no restriction beyond the manifest itself". */
function deployableForGuild(enabledIds) {
  const base = deployable();
  if (!enabledIds) return base;
  const allowed = new Set(enabledIds);
  return base.filter((p) => allowed.has(p.id));
}

function requiredFlags(panelId) {
  return byId(panelId)?.required_flags ?? [];
}

function optionalFlags(panelId) {
  return byId(panelId)?.optional_flags ?? [];
}

module.exports = {
  all,
  byId,
  deployable,
  listable,
  deployableForGuild,
  requiredFlags,
  optionalFlags,
};
