// deploy/progressReporter.js — turns the frequent STEP:/OK:/WARN: updates
// from deployRunner into infrequent Discord message edits. Build brief
// section 4: "Stream progress back into Discord via periodic message
// edits... not raw live output — Discord rate-limits edits."

const config = require('../config/config');
const embeds = require('../ui/embeds');

const MAX_RECENT_OK = 4;

/**
 * @param {import('discord.js').Message} message  the message to keep editing
 * @param {object} meta  { panelId, targetLabel }
 */
function createProgressReporter(message, meta) {
  const state = {
    currentStep: 'Starting\u2026',
    recentOk: [],
    warnings: [],
  };
  let lastEditAt = 0;
  let editTimer = null;
  let editInFlight = Promise.resolve();

  function render() {
    const fields = [{ name: 'Current step', value: state.currentStep }];
    if (state.recentOk.length) {
      fields.push({ name: 'Recently completed', value: state.recentOk.map((l) => `\u2022 ${l}`).join('\n') });
    }
    if (state.warnings.length) {
      fields.push({ name: 'Warnings so far', value: state.warnings.map((l) => `\u2022 ${l}`).join('\n') });
    }
    return embeds.accent({
      title: `Deploying ${meta.panelId} \u2192 ${meta.targetLabel}`,
      description: 'This can take several minutes \u2014 image pulls and migrations are the slow part.',
      fields,
    });
  }

  function flush() {
    lastEditAt = Date.now();
    editInFlight = editInFlight.then(() => message.edit({ embeds: [render()] }).catch(() => {}));
    return editInFlight;
  }

  function scheduleEdit() {
    const elapsed = Date.now() - lastEditAt;
    if (elapsed >= config.execution.progressEditIntervalMs) {
      flush();
      return;
    }
    if (editTimer) return;
    editTimer = setTimeout(() => {
      editTimer = null;
      flush();
    }, config.execution.progressEditIntervalMs - elapsed);
  }

  function onProgress(update) {
    if (update.type === 'step') {
      state.currentStep = update.text;
    } else if (update.type === 'ok') {
      state.recentOk.push(update.text);
      if (state.recentOk.length > MAX_RECENT_OK) state.recentOk.shift();
    } else if (update.type === 'warn') {
      state.warnings.push(update.text);
    } else if (update.type === 'panel_id_mismatch') {
      state.currentStep = 'Aborting \u2014 routing mismatch detected';
    } else if (update.type === 'done') {
      state.currentStep = update.text;
    }
    scheduleEdit();
  }

  async function finalize() {
    if (editTimer) {
      clearTimeout(editTimer);
      editTimer = null;
    }
    await editInFlight;
  }

  return { onProgress, finalize };
}

module.exports = { createProgressReporter };
