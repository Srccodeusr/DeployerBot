// deploy/pendingDeployStore.js — holds a /deploy request between the
// initial slash command reply and the "Advanced options" / "Deploy now" /
// "Cancel" buttons that follow it. Deliberately in-memory only: this is a
// few minutes of UI state, not a durable record (the durable record is
// database/models/deployments.js, created once the user actually confirms).
//
// Keyed by a short random token embedded in each button's customId
// (deploy:start:<token>) rather than the interaction/message id, so it
// survives the confirm message being edited.

const crypto = require('node:crypto');

const TTL_MS = 10 * 60 * 1000;
const store = new Map();

function create(data) {
  const token = crypto.randomBytes(6).toString('hex');
  store.set(token, { ...data, createdAt: Date.now() });
  return token;
}

function get(token) {
  const entry = store.get(token);
  if (!entry) return null;
  if (Date.now() - entry.createdAt > TTL_MS) {
    store.delete(token);
    return null;
  }
  return entry;
}

function update(token, patch) {
  const entry = get(token);
  if (!entry) return null;
  const next = { ...entry, ...patch };
  store.set(token, next);
  return next;
}

function remove(token) {
  store.delete(token);
}

// Periodic sweep so a long-running process doesn't accumulate abandoned
// entries from users who never click a button.
setInterval(() => {
  const now = Date.now();
  for (const [token, entry] of store.entries()) {
    if (now - entry.createdAt > TTL_MS) store.delete(token);
  }
}, 60 * 1000).unref();

module.exports = { create, get, update, remove };
