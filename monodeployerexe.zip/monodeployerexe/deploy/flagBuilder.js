// deploy/flagBuilder.js — lib/common/lib.sh's parse_flags rejects any
// --key its ARGS map doesn't declare (fail closed, on purpose — see the
// library's own comments). So before building argv, every value has to be
// filtered down to exactly the required_flags/optional_flags a panel's
// lib/panels.json entry lists — passing e.g. --email to Convoy (which
// doesn't declare it) would make the install exit 2 for a reason the user
// didn't cause.

const panelManifest = require('../deploy/panelManifest');

/**
 * @param {string} panelId
 * @param {Record<string,string|number|undefined>} candidateFlags  every
 *   value the user could plausibly have supplied, keyed by flag name
 *   (without the leading --). Values that are undefined/empty, or not in
 *   this panel's declared flag set, are dropped silently — this is
 *   filtering to the contract, not a user error.
 * @returns {{flags: Record<string,string|number>, missingRequired: string[]}}
 */
function buildFlagsForPanel(panelId, candidateFlags) {
  const required = panelManifest.requiredFlags(panelId);
  const optional = panelManifest.optionalFlags(panelId);
  const allowed = new Set([...required, ...optional]);

  const flags = {};
  for (const [key, value] of Object.entries(candidateFlags)) {
    if (value === undefined || value === null || value === '') continue;
    if (!allowed.has(key)) continue;
    flags[key] = value;
  }

  const missingRequired = required.filter((key) => flags[key] === undefined);
  return { flags, missingRequired };
}

module.exports = { buildFlagsForPanel };
