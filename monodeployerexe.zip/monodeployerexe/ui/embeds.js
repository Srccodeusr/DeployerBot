// ui/embeds.js — every embed in the bot goes through here so branding
// (build brief section 1: dark neutral + one accent, no emojis, consistent
// footer) stays consistent without every command re-typing it.

const { EmbedBuilder } = require('discord.js');
const config = require('../config/config');

function withFooter(embed) {
  return embed.setFooter({ text: config.branding.footer }).setTimestamp();
}

function base({ title, description, color = config.branding.colors.neutral, fields } = {}) {
  const embed = new EmbedBuilder().setColor(color);
  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (fields?.length) embed.addFields(fields);
  return withFooter(embed);
}

function accent(opts) {
  return base({ ...opts, color: config.branding.colors.accent });
}

function success(opts) {
  return base({ ...opts, color: config.branding.colors.accent });
}

function warning(opts) {
  return base({ ...opts, color: config.branding.colors.warning });
}

function danger(opts) {
  return base({ ...opts, color: config.branding.colors.danger });
}

module.exports = { base, accent, success, warning, danger };
