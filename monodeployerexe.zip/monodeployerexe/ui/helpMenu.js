// ui/helpMenu.js — /help renders this: a dropdown category browser rather
// than a wall of text (build brief section 1), matching how MonoMusic's
// other bots structure /help.

const { ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const embeds = require('./embeds');

const CATEGORIES = {
  utility: {
    label: 'Utility',
    description: 'Latency, bot info',
    commands: [
      { name: '/ping', desc: 'Check the bot\u2019s latency.' },
      { name: '/info', desc: 'About MonoDeployerExE — version and supported panels.' },
    ],
  },
  deployment: {
    label: 'Deployment',
    description: 'Deploy and manage hosting panels',
    commands: [
      { name: '/deploy', desc: 'Deploy a panel locally or to a saved VPS.' },
      { name: '/panels', desc: 'List supported panels, their requirements, and current status.' },
      { name: '/status', desc: 'Check a past deployment, or live-check a reachable panel.' },
      { name: '/logs', desc: 'Retrieve the full log for a past deployment.' },
      { name: '/tunnel', desc: 'Add, change, or remove a Cloudflare Tunnel for a deployment.' },
      { name: '/uninstall', desc: 'Remove a previously deployed panel. Destructive — asks for confirmation.' },
    ],
  },
  vps: {
    label: 'VPS Profiles',
    description: 'Save remote connection details',
    commands: [
      { name: '/vps add', desc: 'Save a VPS connection profile for future deploys.' },
      { name: '/vps list', desc: 'List your saved VPS profiles.' },
      { name: '/vps remove', desc: 'Delete a saved VPS profile.' },
    ],
  },
  admin: {
    label: 'Admin',
    description: 'Server configuration and audit log',
    commands: [
      { name: '/admin role', desc: 'Set the bot-admin role for this server.' },
      { name: '/admin panels', desc: 'Choose which panels are enabled here.' },
      { name: '/admin targets', desc: 'Enable or disable local/remote deploy targets.' },
      { name: '/admin credentials', desc: 'View or revoke stored VPS profiles for this server.' },
      { name: '/admin audit', desc: 'View the deployment and admin-action history.' },
    ],
  },
};

function buildMenu(selected = null) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId('help:category')
    .setPlaceholder('Choose a category\u2026')
    .addOptions(
      Object.entries(CATEGORIES).map(([value, cat]) => ({
        label: cat.label,
        description: cat.description,
        value,
        default: value === selected,
      })),
    );
  return new ActionRowBuilder().addComponents(menu);
}

function landingEmbed() {
  return embeds.accent({
    title: 'MonoDeployerExE — Help',
    description:
      'Pick a category from the dropdown below to see its commands.\n\n' +
      'MonoDeployerExE deploys game/bot hosting panels — locally or to a VPS you provide — ' +
      'inside isolated, resource-capped Docker containers wherever a panel supports it.',
  });
}

function categoryEmbed(categoryKey) {
  const cat = CATEGORIES[categoryKey];
  if (!cat) return landingEmbed();
  return embeds.accent({
    title: `Help — ${cat.label}`,
    description: cat.commands.map((c) => `**${c.name}**\n${c.desc}`).join('\n\n'),
  });
}

module.exports = { CATEGORIES, buildMenu, landingEmbed, categoryEmbed };
