// ui/components.js — small factory functions for the buttons/select menus
// reused across commands, so customId formats live in exactly one place.
// Format convention: "namespace:action:...args" — interactions/ handlers
// match on the first two segments.

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

function confirmRow({ namespace, action, args = [], confirmLabel = 'Confirm', cancelLabel = 'Cancel' }) {
  const suffix = args.length ? `:${args.join(':')}` : '';
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`${namespace}:${action}:confirm${suffix}`)
      .setLabel(confirmLabel)
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`${namespace}:${action}:cancel${suffix}`)
      .setLabel(cancelLabel)
      .setStyle(ButtonStyle.Secondary),
  );
}

function revealSecretRow({ deploymentId, label = 'Reveal admin password' }) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`secret:reveal:${deploymentId}`)
      .setLabel(label)
      .setStyle(ButtonStyle.Secondary),
  );
}

function advancedOptionsRow({ token }) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`deploy:advanced:${token}`)
      .setLabel('Advanced options')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`deploy:start:${token}`)
      .setLabel('Deploy now')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`deploy:cancel:${token}`)
      .setLabel('Cancel')
      .setStyle(ButtonStyle.Secondary),
  );
}

module.exports = { confirmRow, revealSecretRow, advancedOptionsRow };
