#!/bin/bash
# common/lib.sh — shared helpers for every panel installer in this library.
#
# Source this from each panel script:  source "$(dirname "$0")/../common/lib.sh"
#
# Design goals (why this file exists):
#   1. Every installer must be 100% non-interactive — no `read`, ever.
#      All input comes from long-form flags (--domain=...) so the bot can
#      build the argv list itself and run this over SSH or child_process
#      without anything blocking on stdin.
#   2. Output is structured (STEP: / OK: / ERR: / DONE:) so the bot can
#      parse progress instead of scraping ANSI-colored banners.
#   3. No secret is ever hardcoded. Anything sensitive (DB password, admin
#      password, mail credentials) is either passed in by the caller or
#      generated fresh per run with openssl.
#   4. set -euo pipefail everywhere, plus a trap that emits a final ERR:
#      line and a real exit code, so a hung/failed step is never silently
#      swallowed — the calling bot can tell success from failure.

set -euo pipefail

# ---- structured logging -----------------------------------------------
# These are the only lines the calling bot should treat as machine-readable.
# Keep everything else (if anything) to stderr or omit it.
log_step() { echo "STEP: $*"; }
log_ok()   { echo "OK: $*"; }
log_warn() { echo "WARN: $*"; }
log_err()  { echo "ERR: $*" >&2; }
log_done() { echo "DONE: $*"; }

# Every panel script must call this immediately after parse_flags, before
# any real work starts. It's the caller's (the bot's) sanity check that
# the script it invoked actually is the panel it thinks it invoked — a
# routing bug in /deploy (calling the wrong lib/<panel>/install.sh for
# the panel the user picked) would otherwise only surface as a successful
# deployment of the wrong software, which looks identical to success from
# the bot's side until someone notices the panel is wrong. The bot should
# parse this line and hard-abort (never proceed to run migrations/create
# an admin/etc.) if PANEL_ID doesn't match what the user selected.
announce_panel() {
    echo "PANEL_ID: $1"
}

# ---- fatal error trap ---------------------------------------------------
# Any unhandled failure anywhere in the script (thanks to `set -e`) lands
# here instead of dying silently mid-stream.
_on_err() {
    local exit_code=$?
    local line=$1
    log_err "installer failed at line $line (exit $exit_code)"
    exit "$exit_code"
}
trap '_on_err $LINENO' ERR

# ---- flag parsing --------------------------------------------------------
# Usage in a panel script:
#   declare -A ARGS=( [domain]="" [email]="" [admin-user]="admin" ... )
#   parse_flags ARGS "$@"
# Populates ARGS[key] from --key=value pairs. Unknown flags are rejected
# loudly (fail closed) rather than silently ignored, since a typo'd flag
# silently falling back to a default is exactly how a real deployment
# would go wrong without anyone noticing.
parse_flags() {
    local -n _out=$1
    shift
    for arg in "$@"; do
        case "$arg" in
            --*=*)
                local key="${arg#--}"
                key="${key%%=*}"
                local val="${arg#*=}"
                if [[ -v _out["$key"] ]]; then
                    _out["$key"]="$val"
                else
                    log_err "unknown flag: --$key"
                    exit 2
                fi
                ;;
            *)
                log_err "unrecognized argument: $arg (this installer takes --key=value flags only, never positional/interactive input)"
                exit 2
                ;;
        esac
    done
}

require_flag() {
    local -n _map=$1
    local key=$2
    if [[ -z "${_map[$key]:-}" ]]; then
        log_err "missing required flag: --$key"
        exit 2
    fi
}

# ---- secret generation ---------------------------------------------------
# Never hardcode a password/secret. Always call one of these unless the
# caller supplied a value explicitly.
gen_secret() {
    local len="${1:-24}"
    openssl rand -base64 "$len" | tr -dc 'A-Za-z0-9' | head -c "$len"
}

# ---- root / OS checks -----------------------------------------------------
require_root() {
    if [[ "$(id -u)" -ne 0 ]]; then
        log_err "this installer must run as root (needed for package installs / docker)"
        exit 1
    fi
}

detect_os() {
    # Prints a lowercase OS id (ubuntu / debian / ...) via /etc/os-release,
    # which is more reliable across minimal images than lsb_release.
    if [[ -f /etc/os-release ]]; then
        # shellcheck disable=SC1091
        source /etc/os-release
        echo "${ID,,}"
    else
        log_err "cannot detect OS (/etc/os-release missing)"
        exit 1
    fi
}

# ---- docker prerequisites --------------------------------------------------
# Per the brief: the only thing that should touch the host OS directly is
# making sure Docker + Compose exist. Everything panel-specific runs inside
# the containers a docker-compose.yml defines.
ensure_docker() {
    if command -v docker &>/dev/null && docker compose version &>/dev/null; then
        log_ok "docker + compose already present"
        return 0
    fi
    log_step "installing Docker Engine (official install script)"
    curl -fsSL https://get.docker.com | sh >/dev/null 2>&1
    systemctl enable --now docker >/dev/null 2>&1 || true
    if ! docker compose version &>/dev/null; then
        log_err "docker compose plugin not available after install"
        exit 1
    fi
    log_ok "docker + compose installed"
}

# ---- timeouts for anything that could hang ---------------------------------
# Wrap any step that could block waiting on a network resource or a
# subprocess that might never return, so a bad panel/network state can't
# leave the calling bot's SSH session stuck forever.
run_with_timeout() {
    local seconds=$1
    shift
    if ! timeout "$seconds" "$@"; then
        log_err "step timed out or failed after ${seconds}s: $*"
        exit 1
    fi
}
