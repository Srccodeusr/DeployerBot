#!/bin/bash
# jexactyl/install.sh — non-interactive, Docker Compose install.
#
# Rewritten from Nobita-Cloud's panel/Jexactyl/install.sh, which does a
# native apt install (PHP 8.1 + nginx + MariaDB + Redis + Composer) and
# reads Domain/Confirm/Username/Password from the terminal.
#
# Verified before writing this: Jexactyl/Jexactyl ships an official
# docker-compose.example.yml (develop branch) using the published image
# ghcr.io/jexactyl/jexactyl:latest, with MariaDB + Redis as sibling
# containers — the same shape as Pterodactyl's own Docker distribution,
# since Jexactyl is a Pterodactyl-panel fork. This installer follows that
# official compose shape rather than Nobita's native install.
#
# As with pterodactyl/install.sh: no hardcoded mail account, no fixed DB
# password — both generated or left optional.
#
# Usage:
#   install.sh --domain=panel.example.com --email=admin@example.com \
#              [--admin-user=admin] [--admin-password=...] \
#              [--cpu-limit=2] [--mem-limit=2g]

source "$(dirname "$0")/../common/lib.sh"

declare -A ARGS=(
    [domain]=""
    [email]=""
    [admin-user]="admin"
    [admin-password]=""
    [cpu-limit]="2"
    [mem-limit]="2g"
    [mail-host]=""
    [mail-port]="587"
    [mail-username]=""
    [mail-password]=""
    [install-dir]="/opt/monodeployer/jexactyl"
)
parse_flags ARGS "$@"
require_flag ARGS domain
require_flag ARGS email
require_root
announce_panel "jexactyl"

DOMAIN="${ARGS[domain]}"
EMAIL="${ARGS[email]}"
ADMIN_USER="${ARGS[admin-user]}"
ADMIN_PASSWORD="${ARGS[admin-password]:-$(gen_secret 20)}"
DB_PASSWORD=$(gen_secret 24)
CPU_LIMIT="${ARGS[cpu-limit]}"
MEM_LIMIT="${ARGS[mem-limit]}"
INSTALL_DIR="${ARGS[install-dir]}"

log_step "checking Docker prerequisites"
ensure_docker

log_step "preparing install directory at $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"/{var,nginx,certs,logs}
cd "$INSTALL_DIR"

log_step "generating docker-compose.yml"
cat > docker-compose.yml <<EOF
services:
  database:
    image: mariadb:11
    restart: unless-stopped
    command: --default-authentication-plugin=mysql_native_password
    environment:
      MYSQL_PASSWORD: "${DB_PASSWORD}"
      MYSQL_ROOT_PASSWORD: "${DB_PASSWORD}_root"
      MYSQL_DATABASE: "jexpanel_docker"
      MYSQL_USER: "jexpanel_docker"
    volumes:
      - db_data:/var/lib/mysql
    healthcheck:
      test: ["CMD", "healthcheck.sh", "--connect", "--innodb_initialized"]
      interval: 10s
      timeout: 5s
      retries: 5
    deploy:
      resources:
        limits:
          cpus: "${CPU_LIMIT}"
          memory: ${MEM_LIMIT}

  cache:
    image: redis:alpine
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: 256m

  panel:
    image: ghcr.io/jexactyl/jexactyl:latest
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    depends_on:
      database:
        condition: service_healthy
      cache:
        condition: service_healthy
    volumes:
      - panel_var:/app/var/
      - panel_nginx:/etc/nginx/http.d/
      - panel_certs:/etc/letsencrypt/
      - panel_logs:/app/storage/logs
    environment:
      APP_URL: "https://${DOMAIN}"
      APP_TIMEZONE: "UTC"
      APP_SERVICE_AUTHOR: "noreply@${DOMAIN}"
      APP_ENV: "production"
      APP_ENVIRONMENT_ONLY: "false"
      DB_HOST: database
      DB_PORT: "3306"
      DB_DATABASE: "jexpanel_docker"
      DB_USERNAME: "jexpanel_docker"
      DB_PASSWORD: "${DB_PASSWORD}"
      CACHE_DRIVER: redis
      SESSION_DRIVER: redis
      QUEUE_DRIVER: redis
      REDIS_HOST: cache
      HASHIDS_LENGTH: 8
      MAIL_FROM: "${ARGS[mail-username]:-noreply@${DOMAIN}}"
      MAIL_DRIVER: "${ARGS[mail-host]:+smtp}"
      MAIL_HOST: "${ARGS[mail-host]}"
      MAIL_PORT: "${ARGS[mail-port]}"
      MAIL_USERNAME: "${ARGS[mail-username]}"
      MAIL_PASSWORD: "${ARGS[mail-password]}"
    deploy:
      resources:
        limits:
          cpus: "${CPU_LIMIT}"
          memory: ${MEM_LIMIT}

volumes:
  db_data:
  panel_var:
  panel_nginx:
  panel_certs:
  panel_logs:
EOF
log_ok "compose file written"

log_step "pulling images and starting containers"
run_with_timeout 600 docker compose up -d

log_step "waiting for panel container to become ready"
READY=0
for i in $(seq 1 30); do
    if docker compose exec -T panel php artisan --version &>/dev/null; then
        READY=1
        break
    fi
    sleep 5
done
if [[ "$READY" -ne 1 ]]; then
    log_err "panel container did not become ready in time"
    exit 1
fi
log_ok "panel container ready"

log_step "running migrations"
run_with_timeout 120 docker compose exec -T panel php artisan migrate --seed --force

log_step "creating admin user"
run_with_timeout 60 docker compose exec -T panel php artisan p:user:make \
    --email="$EMAIL" \
    --username="$ADMIN_USER" \
    --name-first="Admin" \
    --name-last="User" \
    --password="$ADMIN_PASSWORD" \
    --admin=1

log_done "jexactyl panel deployed"
echo "RESULT_URL: https://${DOMAIN}"
echo "RESULT_ADMIN_USER: ${ADMIN_USER}"
echo "RESULT_ADMIN_PASSWORD: ${ADMIN_PASSWORD}"
echo "RESULT_COMPOSE_DIR: ${INSTALL_DIR}"
