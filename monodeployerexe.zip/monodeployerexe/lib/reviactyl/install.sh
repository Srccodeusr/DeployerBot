#!/bin/bash
# reviactyl/install.sh — non-interactive, NATIVE install (documented exception).
#
# Why this one is native and not Docker, unlike pterodactyl/ and jexactyl/:
# Reviactyl's own official docs (reviactyl/docs) currently document only the
# native Composer/LAMP install path. A community Docker fork exists
# (reviactyl-community/blueprint-docker) but is not the officially
# maintained path, so per the build brief's own instruction ("if a panel
# genuinely has no viable containerized install, fall back to its native
# installer, but still avoid running it as unrestricted root where a
# scoped system user will do") this installer:
#   - keeps the native PHP/nginx/MariaDB/Redis install Nobita-Cloud also
#     used (same stack Reviactyl's docs describe),
#   - but creates and runs the application under a dedicated unprivileged
#     system user (reviactyl) instead of leaving everything owned by
#     www-data/root the way Nobita's script did,
#   - removes the hardcoded mail account and fixed DB password Nobita's
#     script had, same as the other rewrites in this library.
#
# Revisit this if/when Reviactyl publishes an official Docker path —
# swap this file for a compose-based one like pterodactyl/install.sh.
#
# Usage:
#   install.sh --domain=panel.example.com --email=admin@example.com \
#              [--admin-user=admin] [--admin-password=...]

source "$(dirname "$0")/../common/lib.sh"

declare -A ARGS=(
    [domain]=""
    [email]=""
    [admin-user]="admin"
    [admin-password]=""
    [mail-host]=""
    [mail-port]="587"
    [mail-username]=""
    [mail-password]=""
)
parse_flags ARGS "$@"
require_flag ARGS domain
require_flag ARGS email
require_root
announce_panel "reviactyl"

DOMAIN="${ARGS[domain]}"
EMAIL="${ARGS[email]}"
ADMIN_USER="${ARGS[admin-user]}"
ADMIN_PASSWORD="${ARGS[admin-password]:-$(gen_secret 20)}"
DB_NAME="reviactyl"
DB_USER="reviactyl"
DB_PASS=$(gen_secret 24)
PHP_VERSION="8.3"
SYS_USER="reviactyl"
INSTALL_DIR="/var/www/reviactyl"

log_step "creating scoped system user ($SYS_USER) — app will not run as root"
if ! id "$SYS_USER" &>/dev/null; then
    useradd --system --home "$INSTALL_DIR" --shell /usr/sbin/nologin "$SYS_USER"
fi

log_step "installing OS dependencies"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl apt-transport-https ca-certificates gnupg unzip git tar sudo lsb-release software-properties-common

OS=$(detect_os)
if [[ "$OS" == "ubuntu" ]]; then
    LC_ALL=C.UTF-8 add-apt-repository -y ppa:ondrej/php
elif [[ "$OS" == "debian" ]]; then
    curl -fsSL https://packages.sury.org/php/apt.gpg | gpg --dearmor -o /usr/share/keyrings/sury-php.gpg
    echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] https://packages.sury.org/php/ $(lsb_release -cs) main" \
        | tee /etc/apt/sources.list.d/sury-php.list
else
    log_err "unsupported OS for native Reviactyl install: $OS"
    exit 1
fi

rm -f /usr/share/keyrings/redis-archive-keyring.gpg
curl -fsSL https://packages.redis.io/gpg | gpg --dearmor -o /usr/share/keyrings/redis-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/redis-archive-keyring.gpg] https://packages.redis.io/deb $(lsb_release -cs) main" \
    | tee /etc/apt/sources.list.d/redis.list
apt-get update -y

log_step "installing PHP $PHP_VERSION, nginx, MariaDB, Redis"
apt-get install -y \
    "php${PHP_VERSION}" "php${PHP_VERSION}"-{cli,fpm,common,mysql,mbstring,bcmath,xml,zip,curl,gd,tokenizer,ctype,simplexml,dom} \
    mariadb-server nginx redis-server cron

log_step "installing Composer"
curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer

log_step "downloading Reviactyl panel files"
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"
curl -Lo panel.tar.gz https://github.com/reviactyl/panel/releases/latest/download/panel.tar.gz
tar -xzf panel.tar.gz
chmod -R 755 storage/* bootstrap/cache/

log_step "configuring database"
mariadb -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';"
mariadb -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME};"
mariadb -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'127.0.0.1' WITH GRANT OPTION;"
mariadb -e "FLUSH PRIVILEGES;"

log_step "writing .env"
cp .env.example .env
sed -i "s|APP_URL=.*|APP_URL=https://${DOMAIN}|g" .env
sed -i "s|DB_DATABASE=.*|DB_DATABASE=${DB_NAME}|g" .env
sed -i "s|DB_USERNAME=.*|DB_USERNAME=${DB_USER}|g" .env
sed -i "s|DB_PASSWORD=.*|DB_PASSWORD=${DB_PASS}|g" .env
if [[ -n "${ARGS[mail-host]}" ]]; then
    sed -i "s|MAIL_MAILER=.*|MAIL_MAILER=smtp|g" .env
    sed -i "s|MAIL_HOST=.*|MAIL_HOST=${ARGS[mail-host]}|g" .env
    sed -i "s|MAIL_PORT=.*|MAIL_PORT=${ARGS[mail-port]}|g" .env
    sed -i "s|MAIL_USERNAME=.*|MAIL_USERNAME=${ARGS[mail-username]}|g" .env
    sed -i "s|MAIL_PASSWORD=.*|MAIL_PASSWORD=${ARGS[mail-password]}|g" .env
fi

log_step "installing PHP dependencies"
COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader

log_step "generating app key and running migrations"
php artisan key:generate --force
php artisan migrate --seed --force

log_step "setting ownership to scoped user"
chown -R "${SYS_USER}:${SYS_USER}" "$INSTALL_DIR"

log_step "configuring nginx"
mkdir -p /etc/certs/reviactyl
openssl req -new -newkey rsa:4096 -days 3650 -nodes -x509 \
    -subj "/C=NA/ST=NA/L=NA/O=NA/CN=${DOMAIN}" \
    -keyout /etc/certs/reviactyl/privkey.pem -out /etc/certs/reviactyl/fullchain.pem >/dev/null 2>&1

tee /etc/nginx/sites-available/reviactyl.conf > /dev/null <<EOF
server {
    listen 80;
    server_name ${DOMAIN};
    return 301 https://\$server_name\$request_uri;
}
server {
    listen 443 ssl http2;
    server_name ${DOMAIN};
    root ${INSTALL_DIR}/public;
    index index.php;
    ssl_certificate /etc/certs/reviactyl/fullchain.pem;
    ssl_certificate_key /etc/certs/reviactyl/privkey.pem;
    client_max_body_size 100m;
    location / { try_files \$uri \$uri/ /index.php?\$query_string; }
    location ~ \.php\$ {
        fastcgi_split_path_info ^(.+\.php)(/.+)\$;
        fastcgi_pass unix:/run/php/php${PHP_VERSION}-fpm.sock;
        fastcgi_index index.php;
        include /etc/nginx/fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
    }
    location ~ /\.ht { deny all; }
}
EOF
ln -sf /etc/nginx/sites-available/reviactyl.conf /etc/nginx/sites-enabled/reviactyl.conf
nginx -t
systemctl restart nginx

log_step "setting up queue worker"
tee /etc/systemd/system/reviq.service > /dev/null <<EOF
[Unit]
Description=Reviactyl Queue Worker
After=redis-server.service

[Service]
User=${SYS_USER}
Group=${SYS_USER}
Restart=always
ExecStart=/usr/bin/php ${INSTALL_DIR}/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now redis-server
systemctl enable --now reviq.service

log_step "scheduling cron"
(crontab -u "$SYS_USER" -l 2>/dev/null; echo "* * * * * php ${INSTALL_DIR}/artisan schedule:run >> /dev/null 2>&1") | crontab -u "$SYS_USER" -

log_step "creating admin user"
run_with_timeout 60 php artisan p:user:make -n \
    --email="$EMAIL" \
    --username="$ADMIN_USER" \
    --password="$ADMIN_PASSWORD" \
    --admin=1 \
    --name-first=Admin --name-last=User

log_done "reviactyl panel deployed"
echo "RESULT_URL: https://${DOMAIN}"
echo "RESULT_ADMIN_USER: ${ADMIN_USER}"
echo "RESULT_ADMIN_PASSWORD: ${ADMIN_PASSWORD}"
echo "RESULT_INSTALL_DIR: ${INSTALL_DIR}"
echo "RESULT_MODE: native (no official Docker path at time of writing)"
