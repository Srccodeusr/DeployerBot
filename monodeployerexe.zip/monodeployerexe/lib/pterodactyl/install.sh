#!/bin/bash
# pterodactyl/install.sh — non-interactive, Docker Compose install.
#
# Rewritten from Nobita-Cloud's panel/pterodactyl/install.sh. What changed
# and why:
#   - Nobita's version installs PHP/nginx/MariaDB/Redis/Composer straight
#     onto the host via `apt install`, and restarts nginx/systemd services
#     directly on the OS. That's the exact pattern the build brief (section
#     3) says to avoid. Pterodactyl has a well-established official Docker
#     path, so this version uses it instead: panel + MariaDB + Redis each
#     run as containers defined in a generated docker-compose.yml, with
#     per-container CPU/memory limits.
#   - Nobita's version reads --- er, `read`s --- Domain / Email / Username /
#     Password interactively, with a 10s auto-default timeout for password.
#     Bots can't type at a terminal, so all of that becomes flags.
#   - Nobita's version hardcodes a hardcoded live SMTP account
#     (free.mell@aiomarket.online / a fixed password) into every deployed
#     panel's .env, and uses a fixed DB password ("yourPassword") every
#     time. Both are removed: mail config is optional flags left unset by
#     default, and DB/admin passwords are generated fresh with openssl
#     unless the caller supplies one.
#
# Usage:
#   install.sh --domain=panel.example.com --email=admin@example.com \
#              [--admin-user=admin] [--admin-password=...] \
#              [--cpu-limit=2] [--mem-limit=2g] \
#              [--mail-host=...] [--mail-username=...] [--mail-password=...]

source "$(dirname "$0")/../common/lib.sh"

declare -A ARGS=(
    [domain]=""
    [email]=""
    [admin-user]="admin"
    [admin-password]=""
    [cpu-limit]="2"
    [mem-limit]="2g"
    [mail-host]=""
    [mail-port]="587"
    [mail-username]=""
    [mail-password]=""
    [install-dir]="/opt/monodeployer/pterodactyl"
)
parse_flags ARGS "$@"
require_flag ARGS domain
require_flag ARGS email
require_root
announce_panel "pterodactyl"

DOMAIN="${ARGS[domain]}"
EMAIL="${ARGS[email]}"
ADMIN_USER="${ARGS[admin-user]}"
ADMIN_PASSWORD="${ARGS[admin-password]:-$(gen_secret 20)}"
DB_PASSWORD=$(gen_secret 24)
APP_KEY_SEED=$(gen_secret 32)
CPU_LIMIT="${ARGS[cpu-limit]}"
MEM_LIMIT="${ARGS[mem-limit]}"
INSTALL_DIR="${ARGS[install-dir]}"

log_step "checking Docker prerequisites"
ensure_docker

log_step "preparing install directory at $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"/{var,nginx,certs}
cd "$INSTALL_DIR"

log_step "generating docker-compose.yml"
cat > docker-compose.yml <<EOF
services:
  database:
    image: mariadb:10.11
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: ${DB_PASSWORD}_root
      MYSQL_DATABASE: panel
      MYSQL_USER: pterodactyl
      MYSQL_PASSWORD: ${DB_PASSWORD}
    volumes:
      - db_data:/var/lib/mysql
    deploy:
      resources:
        limits:
          cpus: "${CPU_LIMIT}"
          memory: ${MEM_LIMIT}

  cache:
    image: redis:alpine
    restart: unless-stopped
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: 256m

  panel:
    image: ghcr.io/pterodactyl/panel:latest
    restart: unless-stopped
    ports:
      - "443:443"
      - "80:80"
    environment:
      APP_URL: "https://${DOMAIN}"
      APP_TIMEZONE: "UTC"
      APP_SERVICE_AUTHOR: "noreply@${DOMAIN}"
      TRUSTED_PROXIES: "*"
      DB_HOST: database
      DB_PORT: 3306
      DB_DATABASE: panel
      DB_USERNAME: pterodactyl
      DB_PASSWORD: "${DB_PASSWORD}"
      REDIS_HOST: cache
      CACHE_DRIVER: redis
      SESSION_DRIVER: redis
      QUEUE_DRIVER: redis
      MAIL_FROM: "${ARGS[mail-username]:-noreply@${DOMAIN}}"
      MAIL_DRIVER: "${ARGS[mail-host]:+smtp}"
      MAIL_HOST: "${ARGS[mail-host]}"
      MAIL_PORT: "${ARGS[mail-port]}"
      MAIL_USERNAME: "${ARGS[mail-username]}"
      MAIL_PASSWORD: "${ARGS[mail-password]}"
    volumes:
      - panel_var:/app/var/
      - panel_nginx:/etc/nginx/http.d/
      - panel_certs:/etc/letsencrypt/
      - panel_logs:/app/storage/logs
    depends_on:
      - database
      - cache
    deploy:
      resources:
        limits:
          cpus: "${CPU_LIMIT}"
          memory: ${MEM_LIMIT}

volumes:
  db_data:
  panel_var:
  panel_nginx:
  panel_certs:
  panel_logs:
EOF
log_ok "compose file written"

log_step "pulling images and starting containers"
run_with_timeout 600 docker compose up -d

log_step "waiting for panel container to become ready"
READY=0
for i in $(seq 1 30); do
    if docker compose exec -T panel php artisan --version &>/dev/null; then
        READY=1
        break
    fi
    sleep 5
done
if [[ "$READY" -ne 1 ]]; then
    log_err "panel container did not become ready in time"
    exit 1
fi
log_ok "panel container ready"

log_step "running migrations"
run_with_timeout 120 docker compose exec -T panel php artisan migrate --seed --force

log_step "creating admin user"
run_with_timeout 60 docker compose exec -T panel php artisan p:user:make \
    --email="$EMAIL" \
    --username="$ADMIN_USER" \
    --name-first="Admin" \
    --name-last="User" \
    --password="$ADMIN_PASSWORD" \
    --admin=1

log_done "pterodactyl panel deployed"
echo "RESULT_URL: https://${DOMAIN}"
echo "RESULT_ADMIN_USER: ${ADMIN_USER}"
echo "RESULT_ADMIN_PASSWORD: ${ADMIN_PASSWORD}"
echo "RESULT_COMPOSE_DIR: ${INSTALL_DIR}"
