#!/bin/bash
# convoy/install.sh — non-interactive, Docker Compose install.
#
# Rewritten from Nobita-Cloud's panel/Convoy/install.sh. This was the one
# panel in Nobita-Cloud already using Docker Compose for the app itself —
# closest in spirit to what the build brief wants — but it still had real
# problems:
#   - `read DOMAIN` blocks waiting on a terminal.
#   - It calls `docker compose up -d` but never generates a
#     docker-compose.yml — the original script silently assumes one
#     already exists at /var/www/convoy. That works by luck on the
#     author's own machine and fails everywhere else. This version
#     generates the compose file itself.
#   - It purges apache2 unconditionally, which is destructive on a
#     multi-purpose host and unnecessary once nginx isn't running on the
#     host at all (nginx lives inside the container now).
#   - It hardcodes a live-looking SMTP account into every deployment's
#     .env (see comment in pterodactyl/install.sh for why that's serious,
#     not stylistic). Removed — mail config is optional flags.
#   - DB password: Nobita's version *did* already generate this randomly
#     via openssl when creating a fresh DB, which was the right instinct —
#     kept here, but the "reuse existing DB with a hardcoded fallback
#     password" branch is removed since a bot-driven deploy should never
#     silently reuse a guessed password.
#   - No CPU/memory limits on the containers — added per section 3 of the
#     build brief.
#
# Usage:
#   install.sh --domain=panel.example.com [--cpu-limit=2] [--mem-limit=2g]

source "$(dirname "$0")/../common/lib.sh"

declare -A ARGS=(
    [domain]=""
    [cpu-limit]="2"
    [mem-limit]="2g"
    [mail-host]=""
    [mail-port]="587"
    [mail-username]=""
    [mail-password]=""
    [install-dir]="/opt/monodeployer/convoy"
)
parse_flags ARGS "$@"
require_flag ARGS domain
require_root
announce_panel "convoy"

DOMAIN="${ARGS[domain]}"
DB_NAME="convoy"
DB_USER="convoy_user"
DB_PASS=$(gen_secret 24)
REDIS_PASS=$(gen_secret 16)
CPU_LIMIT="${ARGS[cpu-limit]}"
MEM_LIMIT="${ARGS[mem-limit]}"
INSTALL_DIR="${ARGS[install-dir]}"

log_step "checking Docker prerequisites"
ensure_docker

log_step "preparing install directory at $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

if [[ ! -f panel.tar.gz && ! -d storage ]]; then
    log_step "downloading Convoy panel files"
    curl -Lo panel.tar.gz https://github.com/convoypanel/panel/releases/latest/download/panel.tar.gz
    tar -xzf panel.tar.gz
    chmod -R o+w storage/* bootstrap/cache/
fi

if [[ ! -f .env ]]; then
    cp .env.example .env
fi
sed -i "s|APP_URL=.*|APP_URL=https://${DOMAIN}|g" .env
sed -i "s|DB_DATABASE=.*|DB_DATABASE=${DB_NAME}|g" .env
sed -i "s|DB_USERNAME=.*|DB_USERNAME=${DB_USER}|g" .env
sed -i "s|DB_PASSWORD=.*|DB_PASSWORD=${DB_PASS}|g" .env
sed -i "s|REDIS_PASSWORD=.*|REDIS_PASSWORD=${REDIS_PASS}|g" .env
sed -i "s|APP_ENV=.*|APP_ENV=production|g" .env
sed -i "s|APP_DEBUG=.*|APP_DEBUG=false|g" .env
if [[ -n "${ARGS[mail-host]}" ]]; then
    sed -i "s|MAIL_MAILER=.*|MAIL_MAILER=smtp|g" .env
    sed -i "s|MAIL_HOST=.*|MAIL_HOST=${ARGS[mail-host]}|g" .env
    sed -i "s|MAIL_PORT=.*|MAIL_PORT=${ARGS[mail-port]}|g" .env
    sed -i "s|MAIL_USERNAME=.*|MAIL_USERNAME=${ARGS[mail-username]}|g" .env
    sed -i "s|MAIL_PASSWORD=.*|MAIL_PASSWORD=${ARGS[mail-password]}|g" .env
fi
log_ok ".env configured"

log_step "generating docker-compose.yml"
cat > docker-compose.yml <<EOF
services:
  database:
    image: mariadb:10.11
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: "${DB_PASS}_root"
      MYSQL_DATABASE: "${DB_NAME}"
      MYSQL_USER: "${DB_USER}"
      MYSQL_PASSWORD: "${DB_PASS}"
    volumes:
      - db_data:/var/lib/mysql
    deploy:
      resources:
        limits:
          cpus: "${CPU_LIMIT}"
          memory: ${MEM_LIMIT}

  workspace:
    image: convoypanel/panel:latest
    restart: unless-stopped
    working_dir: /var/www/html
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ${INSTALL_DIR}:/var/www/html
    depends_on:
      - database
    deploy:
      resources:
        limits:
          cpus: "${CPU_LIMIT}"
          memory: ${MEM_LIMIT}

volumes:
  db_data:
EOF
log_ok "compose file written"

log_step "starting containers"
run_with_timeout 600 docker compose up -d

log_step "waiting for workspace container to become ready"
READY=0
for i in $(seq 1 30); do
    if docker compose exec -T workspace php artisan --version &>/dev/null; then
        READY=1
        break
    fi
    sleep 5
done
if [[ "$READY" -ne 1 ]]; then
    log_err "workspace container did not become ready in time"
    exit 1
fi
log_ok "workspace container ready"

log_step "installing PHP dependencies"
run_with_timeout 300 docker compose exec -T workspace bash -c "composer install --no-dev --optimize-autoloader"

log_step "generating app key"
run_with_timeout 60 docker compose exec -T workspace bash -c "php artisan key:generate --force && php artisan optimize"

log_step "running migrations"
run_with_timeout 120 docker compose exec -T workspace php artisan migrate --force

log_warn "Convoy's admin-user creation (c:user:make) is interactive upstream — no flag-driven equivalent confirmed yet. Creating a default admin via tinker is NOT done here to avoid guessing at Convoy's User model shape. Run '/panel-admin' follow-up command after deploy to create the first admin, or confirm the correct artisan flags before automating this step."

log_done "convoy panel deployed"
echo "RESULT_URL: https://${DOMAIN}"
echo "RESULT_COMPOSE_DIR: ${INSTALL_DIR}"
echo "RESULT_DB_PASSWORD: ${DB_PASS}"
echo "RESULT_ADMIN_SETUP: pending — see WARN above"
