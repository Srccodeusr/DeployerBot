#!/bin/bash
# mythicaldash/install.sh — non-interactive wrapper around the official
# MythicalDash installer, Docker-based.
#
# Why this file looks different from pterodactyl/ and jexactyl/:
# I confirmed MythicalDash's Docker support is real and current (their
# GitHub releases note "Docker installs are now working and forced by
# default"), and their install docs live at docs.mythicalsystems.me — but
# I have not independently pulled and verified the exact contents of
# their docker-compose.yml the way I did for Pterodactyl and Jexactyl
# (whose compose files I fetched and read directly). Rather than
# hand-write compose service names, image tags, and env vars I have not
# actually seen — which is exactly the kind of guess the build brief says
# not to make — this script fetches and runs MythicalDash's own official
# installer non-interactively, the same pattern the brief itself uses for
# the Airlink exception.
#
# Before wiring this into the bot for real: fetch and archive the actual
# install script from the URL below, confirm what flags/env vars it
# accepts for non-interactive use (or whether it needs to be driven via
# `expect`/piped stdin like Nobita's version), and replace the placeholder
# call below accordingly.
#
# Usage:
#   install.sh --domain=panel.example.com [--cpu-limit=2] [--mem-limit=2g]

source "$(dirname "$0")/../common/lib.sh"

declare -A ARGS=(
    [domain]=""
    [cpu-limit]="2"
    [mem-limit]="2g"
)
parse_flags ARGS "$@"
require_flag ARGS domain
require_root
announce_panel "mythicaldash"

DOMAIN="${ARGS[domain]}"

log_step "checking Docker prerequisites"
ensure_docker

# --- VERIFY BEFORE USE -----------------------------------------------------
# TODO: confirm the current canonical installer URL and its non-interactive
# flags at https://docs.mythicalsystems.me/ before enabling this in
# production. Nobita-Cloud's own bundled copy only ever asked for a domain
# (see panel/mythical/install.sh), which suggests the official installer
# may already be closer to non-interactive than most of the others in this
# set — but that needs confirming against the current script, not assumed.
log_err "mythicaldash installer not yet wired to a verified non-interactive source — see comment block above. Refusing to run an unverified installer."
exit 3

# Once verified, this should look roughly like:
#   log_step "running official MythicalDash installer (non-interactive)"
#   run_with_timeout 900 bash <(curl -fsSL https://raw.githubusercontent.com/mythicalltd/mythicaldash/main/install.sh) \
#       --domain="$DOMAIN" --non-interactive
#   log_done "mythicaldash deployed"
#   echo "RESULT_URL: https://${DOMAIN}"
