// database/models/deployments.js — one row per /deploy run. This is the
// history record build brief section 8 requires ("every deployment
// attempt, success or failure, recorded"), and what /status, /logs and
// /uninstall read back from.

const db = require('../db');
const crypto = require('../../utils/crypto');

const insertStmt = db.prepare(`
INSERT INTO deployments
  (guild_id, user_id, channel_id, panel_id, target_type, vps_profile_id, host_label, status, started_at)
VALUES
  (@guild_id, @user_id, @channel_id, @panel_id, @target_type, @vps_profile_id, @host_label, 'running', @started_at)
`);

const finishSuccessStmt = db.prepare(`
UPDATE deployments SET
  status = 'success',
  exit_code = @exit_code,
  result_url = @result_url,
  result_admin_user = @result_admin_user,
  encrypted_admin_password = @encrypted_admin_password,
  install_dir = @install_dir,
  log_file = @log_file,
  finished_at = @finished_at
WHERE id = @id
`);

const finishFailureStmt = db.prepare(`
UPDATE deployments SET
  status = @status,
  exit_code = @exit_code,
  error_message = @error_message,
  log_file = @log_file,
  finished_at = @finished_at
WHERE id = @id
`);

const markRevealedStmt = db.prepare('UPDATE deployments SET admin_password_revealed = 1 WHERE id = ?');

const setTunnelStmt = db.prepare(`
UPDATE deployments SET cloudflare_tunnel_installed = 1, encrypted_tunnel_token = @encrypted_tunnel_token WHERE id = @id
`);

const getByIdStmt = db.prepare('SELECT * FROM deployments WHERE id = ?');
const latestForGuildStmt = db.prepare(
  'SELECT * FROM deployments WHERE guild_id = ? ORDER BY started_at DESC LIMIT ?',
);
const latestForUserStmt = db.prepare(
  'SELECT * FROM deployments WHERE guild_id = ? AND user_id = ? ORDER BY started_at DESC LIMIT ?',
);
const latestForInstallDirStmt = db.prepare(`
SELECT * FROM deployments
WHERE guild_id = ? AND panel_id = ? AND status = 'success' AND install_dir IS NOT NULL
ORDER BY started_at DESC LIMIT 1
`);

function start({ guildId, userId, channelId, panelId, targetType, vpsProfileId, hostLabel }) {
  const info = insertStmt.run({
    guild_id: guildId,
    user_id: userId,
    channel_id: channelId,
    panel_id: panelId,
    target_type: targetType,
    vps_profile_id: vpsProfileId ?? null,
    host_label: hostLabel,
    started_at: new Date().toISOString(),
  });
  return info.lastInsertRowid;
}

function finishSuccess(id, { exitCode, resultUrl, resultAdminUser, resultAdminPassword, installDir, logFile }) {
  finishSuccessStmt.run({
    id,
    exit_code: exitCode,
    result_url: resultUrl ?? null,
    result_admin_user: resultAdminUser ?? null,
    encrypted_admin_password: resultAdminPassword ? crypto.encrypt(resultAdminPassword) : null,
    install_dir: installDir ?? null,
    log_file: logFile ?? null,
    finished_at: new Date().toISOString(),
  });
}

function finishFailure(id, { status = 'failed', exitCode, errorMessage, logFile }) {
  finishFailureStmt.run({
    id,
    status,
    exit_code: exitCode ?? null,
    error_message: errorMessage ?? null,
    log_file: logFile ?? null,
    finished_at: new Date().toISOString(),
  });
}

function get(id) {
  return getByIdStmt.get(id);
}

function latestForGuild(guildId, limit = 10) {
  return latestForGuildStmt.all(guildId, limit);
}

function latestForUser(guildId, userId, limit = 10) {
  return latestForUserStmt.all(guildId, userId, limit);
}

/** Used by /uninstall to find the compose/install dir for a panel when the
 * user doesn't pass a specific deployment id. */
function latestSuccessfulInstallDir(guildId, panelId) {
  return latestForInstallDirStmt.get(guildId, panelId);
}

/** Called exactly once, right after the one-time reveal in the /deploy
 * completion flow. Marking this does not change how /status or /logs
 * behave — they never show the plaintext regardless of this flag; it's
 * kept only so /deploy itself can refuse a second reveal attempt on the
 * same completion message. */
function markPasswordRevealed(id) {
  markRevealedStmt.run(id);
}

function decryptAdminPassword(deployment) {
  return deployment.encrypted_admin_password ? crypto.decrypt(deployment.encrypted_admin_password) : null;
}

function recordTunnel(id, token) {
  setTunnelStmt.run({ id, encrypted_tunnel_token: crypto.encrypt(token) });
}

module.exports = {
  start,
  finishSuccess,
  finishFailure,
  get,
  latestForGuild,
  latestForUser,
  latestSuccessfulInstallDir,
  markPasswordRevealed,
  decryptAdminPassword,
  recordTunnel,
};
