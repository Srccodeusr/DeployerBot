// database/models/auditLog.js — append-only trail for every admin action
// and every deploy/uninstall/tunnel attempt (build brief section 8: "every
// deployment attempt... recorded", section 4 admin: "audit/history log").

const db = require('../db');

const insertStmt = db.prepare(`
INSERT INTO audit_log (guild_id, actor_id, action, target, details, created_at)
VALUES (@guild_id, @actor_id, @action, @target, @details, @created_at)
`);

const listStmt = db.prepare('SELECT * FROM audit_log WHERE guild_id = ? ORDER BY created_at DESC LIMIT ?');

function record({ guildId, actorId, action, target = null, details = null }) {
  insertStmt.run({
    guild_id: guildId,
    actor_id: actorId,
    action,
    target,
    details: details ? JSON.stringify(details) : null,
    created_at: new Date().toISOString(),
  });
}

function list(guildId, limit = 20) {
  return listStmt.all(guildId, limit).map((row) => ({
    ...row,
    details: row.details ? JSON.parse(row.details) : null,
  }));
}

module.exports = { record, list };
