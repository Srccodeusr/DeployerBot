// database/models/vpsProfiles.js — saved remote-target connection profiles
// (build brief section 4, `/vps`). Secrets are encrypted before they ever
// reach this file (see interactions/modals/vpsCredentialsModal.js) and
// decrypted only at the moment executors/remoteExecutor.js needs them.

const db = require('../db');
const crypto = require('../../utils/crypto');

const insertStmt = db.prepare(`
INSERT INTO vps_profiles
  (guild_id, user_id, name, host, port, username, auth_method, encrypted_secret, encrypted_passphrase, created_by, created_at)
VALUES
  (@guild_id, @user_id, @name, @host, @port, @username, @auth_method, @encrypted_secret, @encrypted_passphrase, @created_by, @created_at)
`);

const listStmt = db.prepare(
  'SELECT id, name, host, port, username, auth_method, created_at FROM vps_profiles WHERE guild_id = ? AND user_id = ? ORDER BY name',
);

const listAllForGuildStmt = db.prepare(
  'SELECT id, user_id, name, host, port, username, auth_method, created_at FROM vps_profiles WHERE guild_id = ? ORDER BY user_id, name',
);

const getByNameStmt = db.prepare(
  'SELECT * FROM vps_profiles WHERE guild_id = ? AND user_id = ? AND name = ?',
);

const getByIdStmt = db.prepare('SELECT * FROM vps_profiles WHERE id = ?');

const deleteByIdStmt = db.prepare('DELETE FROM vps_profiles WHERE id = ?');
const deleteByNameStmt = db.prepare('DELETE FROM vps_profiles WHERE guild_id = ? AND user_id = ? AND name = ?');

/**
 * @param {object} params
 * @param {'password'|'private-key'} params.authMethod
 * @param {string} params.secret plaintext password or private key PEM — encrypted here, never before
 * @param {string} [params.passphrase] plaintext private-key passphrase, if any
 */
function create({ guildId, userId, name, host, port, username, authMethod, secret, passphrase, createdBy }) {
  insertStmt.run({
    guild_id: guildId,
    user_id: userId,
    name,
    host,
    port,
    username,
    auth_method: authMethod,
    encrypted_secret: crypto.encrypt(secret),
    encrypted_passphrase: passphrase ? crypto.encrypt(passphrase) : null,
    created_by: createdBy,
    created_at: new Date().toISOString(),
  });
}

/** Metadata only — never returns decrypted secrets. Safe for /vps list. */
function listForUser(guildId, userId) {
  return listStmt.all(guildId, userId);
}

/** Metadata only, across the whole guild — for /admin credentials. */
function listForGuild(guildId) {
  return listAllForGuildStmt.all(guildId);
}

function findByName(guildId, userId, name) {
  return getByNameStmt.get(guildId, userId, name);
}

function findById(id) {
  return getByIdStmt.get(id);
}

/** Decrypts on demand for the executor only — callers must not log or
 * forward the return value anywhere it could reach Discord. */
function getDecryptedCredentials(profile) {
  return {
    host: profile.host,
    port: profile.port,
    username: profile.username,
    authMethod: profile.auth_method,
    secret: crypto.decrypt(profile.encrypted_secret),
    passphrase: profile.encrypted_passphrase ? crypto.decrypt(profile.encrypted_passphrase) : undefined,
  };
}

function remove(id) {
  deleteByIdStmt.run(id);
}

function removeByName(guildId, userId, name) {
  deleteByNameStmt.run(guildId, userId, name);
}

module.exports = {
  create,
  listForUser,
  listForGuild,
  findByName,
  findById,
  getDecryptedCredentials,
  remove,
  removeByName,
};
