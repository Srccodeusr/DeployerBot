// database/models/guildConfig.js — per-guild settings: which panels/targets
// are enabled here (build brief section 4, admin commands), and the
// configurable bot-admin role.

const db = require('../db');

const upsertStmt = db.prepare(`
INSERT INTO guild_config (guild_id, admin_role_id, enabled_panel_ids, allow_local_target, allow_remote_target, updated_at)
VALUES (@guild_id, @admin_role_id, @enabled_panel_ids, @allow_local_target, @allow_remote_target, @updated_at)
ON CONFLICT(guild_id) DO UPDATE SET
  admin_role_id       = excluded.admin_role_id,
  enabled_panel_ids   = excluded.enabled_panel_ids,
  allow_local_target  = excluded.allow_local_target,
  allow_remote_target = excluded.allow_remote_target,
  updated_at          = excluded.updated_at
`);

const getStmt = db.prepare('SELECT * FROM guild_config WHERE guild_id = ?');

function defaults(guildId) {
  return {
    guild_id: guildId,
    admin_role_id: null,
    enabled_panel_ids: null, // null = "all ready/partial panels", set by /admin panels
    allow_local_target: 1,
    allow_remote_target: 1,
    updated_at: new Date().toISOString(),
  };
}

function get(guildId) {
  const row = getStmt.get(guildId);
  if (!row) return defaults(guildId);
  return {
    ...row,
    enabled_panel_ids: row.enabled_panel_ids ? JSON.parse(row.enabled_panel_ids) : null,
    allow_local_target: !!row.allow_local_target,
    allow_remote_target: !!row.allow_remote_target,
  };
}

function setAdminRole(guildId, roleId) {
  const current = get(guildId);
  upsertStmt.run({
    guild_id: guildId,
    admin_role_id: roleId,
    enabled_panel_ids: current.enabled_panel_ids ? JSON.stringify(current.enabled_panel_ids) : null,
    allow_local_target: current.allow_local_target ? 1 : 0,
    allow_remote_target: current.allow_remote_target ? 1 : 0,
    updated_at: new Date().toISOString(),
  });
}

function setEnabledPanels(guildId, panelIds) {
  const current = get(guildId);
  upsertStmt.run({
    guild_id: guildId,
    admin_role_id: current.admin_role_id,
    enabled_panel_ids: JSON.stringify(panelIds),
    allow_local_target: current.allow_local_target ? 1 : 0,
    allow_remote_target: current.allow_remote_target ? 1 : 0,
    updated_at: new Date().toISOString(),
  });
}

function setTargetsAllowed(guildId, { local, remote }) {
  const current = get(guildId);
  upsertStmt.run({
    guild_id: guildId,
    admin_role_id: current.admin_role_id,
    enabled_panel_ids: current.enabled_panel_ids ? JSON.stringify(current.enabled_panel_ids) : null,
    allow_local_target: local ? 1 : 0,
    allow_remote_target: remote ? 1 : 0,
    updated_at: new Date().toISOString(),
  });
}

module.exports = { get, setAdminRole, setEnabledPanels, setTargetsAllowed };
