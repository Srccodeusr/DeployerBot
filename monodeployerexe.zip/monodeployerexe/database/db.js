// database/db.js — SQLite via better-sqlite3 (synchronous, no ORM).
// Real secrets (VPS credentials, tunnel tokens, generated admin passwords)
// are encrypted by callers via utils/crypto.js *before* they reach this
// file — this module never sees plaintext for those columns.

const fs = require('node:fs');
const path = require('node:path');
const Database = require('better-sqlite3');
const config = require('../config/config');
const logger = require('../utils/logger').create('database');

fs.mkdirSync(path.dirname(config.storage.databasePath), { recursive: true });
fs.mkdirSync(config.storage.logDir, { recursive: true });

const db = new Database(config.storage.databasePath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS guild_config (
  guild_id            TEXT PRIMARY KEY,
  admin_role_id       TEXT,
  enabled_panel_ids   TEXT NOT NULL DEFAULT '[]',   -- JSON array of panel ids
  allow_local_target  INTEGER NOT NULL DEFAULT 1,
  allow_remote_target INTEGER NOT NULL DEFAULT 1,
  updated_at          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS vps_profiles (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id            TEXT NOT NULL,
  user_id             TEXT NOT NULL,
  name                TEXT NOT NULL,
  host                TEXT NOT NULL,
  port                INTEGER NOT NULL DEFAULT 22,
  username            TEXT NOT NULL,
  auth_method         TEXT NOT NULL CHECK (auth_method IN ('password', 'private-key')),
  encrypted_secret    TEXT NOT NULL,   -- password or private key, AES-256-GCM packed
  encrypted_passphrase TEXT,           -- optional private-key passphrase
  created_by          TEXT NOT NULL,
  created_at          TEXT NOT NULL,
  UNIQUE(guild_id, user_id, name)
);

CREATE TABLE IF NOT EXISTS deployments (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id            TEXT NOT NULL,
  user_id             TEXT NOT NULL,
  channel_id          TEXT NOT NULL,
  panel_id            TEXT NOT NULL,
  target_type         TEXT NOT NULL CHECK (target_type IN ('local', 'remote')),
  vps_profile_id      INTEGER REFERENCES vps_profiles(id) ON DELETE SET NULL,
  host_label          TEXT,            -- display-only, e.g. "this machine" or "vps:my-box"
  status              TEXT NOT NULL DEFAULT 'running'
                        CHECK (status IN ('running','success','failed','blocked','aborted')),
  exit_code           INTEGER,
  result_url          TEXT,
  result_admin_user   TEXT,
  encrypted_admin_password TEXT,       -- RESULT_ADMIN_PASSWORD, never re-echoed after first reveal
  admin_password_revealed  INTEGER NOT NULL DEFAULT 0,
  install_dir         TEXT,            -- RESULT_COMPOSE_DIR / RESULT_INSTALL_DIR, needed by /uninstall
  cloudflare_tunnel_installed INTEGER NOT NULL DEFAULT 0,
  encrypted_tunnel_token TEXT,
  log_file            TEXT,            -- path under config.storage.logDir
  error_message       TEXT,
  started_at          TEXT NOT NULL,
  finished_at         TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id            TEXT NOT NULL,
  actor_id            TEXT NOT NULL,
  action              TEXT NOT NULL,
  target              TEXT,
  details             TEXT,
  created_at          TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_deployments_guild ON deployments(guild_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_vps_profiles_lookup ON vps_profiles(guild_id, user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_guild ON audit_log(guild_id, created_at DESC);
`);

logger.info(`database ready at ${config.storage.databasePath}`);

module.exports = db;
