// handlers/interactionHandler.js — loads every module under
// interactions/{buttons,selectMenus,modals} and routes an incoming
// interaction to the one whose customIdPrefix matches, segment-by-segment
// (not a raw string prefix — "deploy:advanced" must not accidentally
// match "deploy:advancedSubmit:...", which a plain startsWith() would).

const fs = require('node:fs');
const path = require('node:path');

function loadDir(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith('.js'))
    .map((f) => {
      // eslint-disable-next-line global-require, import/no-dynamic-require
      const mod = require(path.join(dir, f));
      if (!mod?.customIdPrefix || !mod?.execute) {
        // eslint-disable-next-line no-console
        console.warn(`[interactionHandler] skipping ${f} — missing customIdPrefix/execute export`);
        return null;
      }
      return mod;
    })
    .filter(Boolean);
}

function segmentsMatch(customId, prefix) {
  const idParts = customId.split(':');
  const prefixParts = prefix.split(':');
  if (idParts.length < prefixParts.length) return false;
  return prefixParts.every((part, i) => idParts[i] === part);
}

function findHandler(handlers, customId) {
  // Longest matching prefix wins, so a more specific handler (more
  // segments) is preferred over a shorter one that also happens to match.
  let best = null;
  for (const handler of handlers) {
    if (segmentsMatch(customId, handler.customIdPrefix)) {
      if (!best || handler.customIdPrefix.length > best.customIdPrefix.length) best = handler;
    }
  }
  return best;
}

function loadInteractionHandlers() {
  const base = path.join(__dirname, '..', 'interactions');
  return {
    buttons: loadDir(path.join(base, 'buttons')),
    selectMenus: loadDir(path.join(base, 'selectMenus')),
    modals: loadDir(path.join(base, 'modals')),
  };
}

module.exports = { loadInteractionHandlers, findHandler };
