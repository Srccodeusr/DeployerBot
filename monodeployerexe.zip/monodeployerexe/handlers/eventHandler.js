// handlers/eventHandler.js — loads every module under events/, each
// exporting { name, once?, execute(...args) }, and registers it on the
// client.

const fs = require('node:fs');
const path = require('node:path');

function loadEvents(client) {
  const eventsDir = path.join(__dirname, '..', 'events');
  const files = fs.readdirSync(eventsDir).filter((f) => f.endsWith('.js'));
  for (const file of files) {
    // eslint-disable-next-line global-require, import/no-dynamic-require
    const event = require(path.join(eventsDir, file));
    if (!event?.name || !event?.execute) {
      // eslint-disable-next-line no-console
      console.warn(`[eventHandler] skipping ${file} — missing name/execute export`);
      continue;
    }
    if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
    else client.on(event.name, (...args) => event.execute(...args, client));
  }
}

module.exports = { loadEvents };
