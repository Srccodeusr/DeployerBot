// handlers/commandHandler.js — recursively loads every command module
// under commands/ into a Collection keyed by slash command name. Used
// both by index.js (to dispatch interactions) and deploy-commands.js (to
// know what to register with Discord).

const fs = require('node:fs');
const path = require('node:path');
const { Collection } = require('discord.js');

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else if (entry.name.endsWith('.js')) files.push(full);
  }
  return files;
}

function loadCommands() {
  const commandsDir = path.join(__dirname, '..', 'commands');
  const commands = new Collection();
  for (const file of walk(commandsDir)) {
    // eslint-disable-next-line global-require, import/no-dynamic-require
    const command = require(file);
    if (!command?.data || !command?.execute) {
      // eslint-disable-next-line no-console
      console.warn(`[commandHandler] skipping ${file} — missing data/execute export`);
      continue;
    }
    commands.set(command.data.name, command);
  }
  return commands;
}

module.exports = { loadCommands };
