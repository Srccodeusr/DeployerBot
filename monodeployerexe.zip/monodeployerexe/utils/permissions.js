// utils/permissions.js — gate for every admin subcommand (build brief
// section 4: "permission-gated to server admins/a configurable bot-admin
// role"). Checked in one place so every admin command applies the same
// rule instead of re-implementing it.

const { PermissionFlagsBits } = require('discord.js');
const config = require('../config/config');
const guildConfig = require('../database/models/guildConfig');

/**
 * @param {import('discord.js').Interaction} interaction
 * @returns {boolean}
 */
function isBotAdmin(interaction) {
  if (config.ownerIds.includes(interaction.user.id)) return true;
  if (!interaction.inGuild()) return false;

  const member = interaction.member;
  if (member?.permissions?.has(PermissionFlagsBits.Administrator)) return true;
  if (member?.permissions?.has(PermissionFlagsBits.ManageGuild)) return true;

  const { admin_role_id: adminRoleId } = guildConfig.get(interaction.guildId);
  if (adminRoleId && member?.roles?.cache?.has(adminRoleId)) return true;

  return false;
}

module.exports = { isBotAdmin };
