// utils/validators.js — input validation shared by deploy/vps/tunnel
// commands. Keeping this separate from the command files means the same
// rules apply whether a value came from a slash command option or a modal.

const DOMAIN_RE = /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isValidDomain(value) {
  return typeof value === 'string' && DOMAIN_RE.test(value.trim());
}

function isValidEmail(value) {
  return typeof value === 'string' && EMAIL_RE.test(value.trim());
}

function isValidPort(value) {
  const n = Number(value);
  return Number.isInteger(n) && n > 0 && n <= 65535;
}

/** cpu-limit is passed straight into a Docker Compose `cpus:` field, so
 * keep it to a sane decimal range rather than letting an install request
 * ask for an unbounded number of cores. */
function isValidCpuLimit(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 && n <= 32;
}

/** mem-limit follows Compose's own shorthand (e.g. "512m", "2g"). */
const MEM_LIMIT_RE = /^[0-9]+(b|k|m|g)$/i;
function isValidMemLimit(value) {
  return typeof value === 'string' && MEM_LIMIT_RE.test(value.trim());
}

/** Redact anything that looks like a secret before it could ever land in
 * a Discord message, error embed, or console log. Build brief section 8:
 * never log or echo SSH credentials, tunnel tokens, or admin passwords. */
function redact(value) {
  if (!value) return value;
  const str = String(value);
  if (str.length <= 4) return '****';
  return `${str.slice(0, 2)}${'*'.repeat(Math.max(4, str.length - 4))}${str.slice(-2)}`;
}

/** Strip anything that could plausibly be a secret out of a free-text
 * error string before it's shown in Discord (e.g. an SSH library error
 * that happened to include a password in a connection string). Best
 * effort, not a substitute for never passing secrets through error paths
 * in the first place. */
function scrubSecrets(text, secrets = []) {
  let out = String(text);
  for (const secret of secrets) {
    if (!secret) continue;
    out = out.split(secret).join('[REDACTED]');
  }
  return out;
}

module.exports = {
  isValidDomain,
  isValidEmail,
  isValidPort,
  isValidCpuLimit,
  isValidMemLimit,
  redact,
  scrubSecrets,
};
