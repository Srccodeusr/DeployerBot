// utils/logger.js — small structured console logger. Deliberately not a
// dependency (pino/winston) since the bot's actual audit trail lives in
// SQLite (database/models/auditLog.js) and per-deployment log files
// (deploy/deployRunner.js); this is just for operator-facing console output.

const LEVELS = ['debug', 'info', 'warn', 'error'];

function ts() {
  return new Date().toISOString();
}

function make(scope) {
  const logger = {};
  for (const level of LEVELS) {
    logger[level] = (...args) => {
      const line = `[${ts()}] [${level.toUpperCase()}] [${scope}]`;
      // eslint-disable-next-line no-console
      console[level === 'debug' ? 'log' : level](line, ...args);
    };
  }
  logger.child = (childScope) => make(`${scope}:${childScope}`);
  return logger;
}

module.exports = { create: make };
