// utils/crypto.js — AES-256-GCM for everything that touches
// database/models/*.js: VPS passwords/private keys, Cloudflare tunnel
// tokens, generated panel-admin passwords. Build brief section 2/8: real
// secrets, not playlist data, so this is not the plain-JSON-file pattern
// used by MonoMusic's other bots.
//
// Storage shape for an encrypted field is a single string:
//   base64(iv) + '.' + base64(authTag) + '.' + base64(ciphertext)
// so callers can persist one TEXT column instead of three.

const crypto = require('node:crypto');
const config = require('../config/config');

const ALGO = 'aes-256-gcm';
const IV_LENGTH = 12; // 96-bit nonce, standard for GCM

let cachedKey = null;
function getKey() {
  if (cachedKey) return cachedKey;
  const raw = Buffer.from(config.security.encryptionKey, 'base64');
  if (raw.length !== 32) {
    throw new Error(
      `[crypto] ENCRYPTION_KEY must decode to exactly 32 bytes (got ${raw.length}). ` +
        `Generate one with: node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`,
    );
  }
  cachedKey = raw;
  return cachedKey;
}

/**
 * Encrypt a UTF-8 string. Returns the packed string described above, or
 * null if the input was null/undefined (so optional secret fields don't
 * need special-casing at every call site).
 */
function encrypt(plaintext) {
  if (plaintext === null || plaintext === undefined) return null;
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGO, getKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return [iv.toString('base64'), authTag.toString('base64'), ciphertext.toString('base64')].join('.');
}

/**
 * Reverse of encrypt(). Throws if the payload was tampered with or the key
 * is wrong (GCM auth tag mismatch) rather than returning corrupted data.
 */
function decrypt(packed) {
  if (packed === null || packed === undefined) return null;
  const [ivB64, tagB64, dataB64] = String(packed).split('.');
  if (!ivB64 || !tagB64 || !dataB64) {
    throw new Error('[crypto] malformed ciphertext payload');
  }
  const iv = Buffer.from(ivB64, 'base64');
  const authTag = Buffer.from(tagB64, 'base64');
  const ciphertext = Buffer.from(dataB64, 'base64');
  const decipher = crypto.createDecipheriv(ALGO, getKey(), iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
}

/** Cryptographically random alphanumeric string, for local fallbacks
 * (the install scripts generate their own secrets server-side via
 * openssl; this is for bot-side needs like one-time reveal tokens). */
function randomToken(bytes = 24) {
  return crypto.randomBytes(bytes).toString('hex');
}

module.exports = { encrypt, decrypt, randomToken };
