// events/interactionCreate.js — the single entry point for every
// interaction. Dispatches chat input commands + their autocomplete to
// handlers/commandHandler.js's Collection, and buttons/select
// menus/modals to handlers/interactionHandler.js's prefix-matched
// modules. Every path is wrapped so one handler throwing doesn't crash
// the process or leave the user's interaction hanging.

const { Events } = require('discord.js');
const { loadInteractionHandlers, findHandler } = require('../handlers/interactionHandler');
const embeds = require('../ui/embeds');
const logger = require('../utils/logger').create('interactionCreate');

const interactionHandlers = loadInteractionHandlers();

async function safeErrorReply(interaction, err) {
  logger.error('unhandled interaction error', err);
  const payload = { embeds: [embeds.danger({ title: 'Something went wrong', description: 'That didn\u2019t complete. Try again, and if it keeps happening, check the bot\u2019s console output.' })] };
  try {
    if (interaction.deferred || interaction.replied) await interaction.editReply(payload);
    else await interaction.reply({ ...payload, ephemeral: true });
  } catch {
    // Interaction may have already expired — nothing more we can do.
  }
}

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    try {
      if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) {
          await interaction.reply({ content: `Unknown command: /${interaction.commandName}`, ephemeral: true });
          return;
        }
        if (command.guildOnly !== false && !interaction.inGuild()) {
          await interaction.reply({ content: 'This command only works inside a server.', ephemeral: true });
          return;
        }
        await command.execute(interaction);
        return;
      }

      if (interaction.isAutocomplete()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command?.autocomplete) {
          await interaction.respond([]);
          return;
        }
        await command.autocomplete(interaction);
        return;
      }

      if (interaction.isButton()) {
        const handler = findHandler(interactionHandlers.buttons, interaction.customId);
        if (!handler) return;
        await handler.execute(interaction);
        return;
      }

      if (interaction.isStringSelectMenu()) {
        const handler = findHandler(interactionHandlers.selectMenus, interaction.customId);
        if (!handler) return;
        await handler.execute(interaction);
        return;
      }

      if (interaction.isModalSubmit()) {
        const handler = findHandler(interactionHandlers.modals, interaction.customId);
        if (!handler) return;
        await handler.execute(interaction);
      }
    } catch (err) {
      if (interaction.isRepliable()) await safeErrorReply(interaction, err);
      else logger.error('unhandled interaction error (not repliable)', err);
    }
  },
};
