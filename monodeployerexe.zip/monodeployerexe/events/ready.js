const { Events } = require('discord.js');
const logger = require('../utils/logger').create('ready');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    logger.info(`logged in as ${client.user.tag} (${client.guilds.cache.size} guild(s))`);
    client.user.setPresence({ activities: [{ name: '/help' }], status: 'online' });
  },
};
