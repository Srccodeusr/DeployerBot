// config/config.js — single place every other module pulls env/branding from.
// Nothing here should read process.env directly outside of this file, so
// there's exactly one spot to check when a deploy target is missing a var.

require('dotenv').config();
const path = require('node:path');

function required(name) {
  const val = process.env[name];
  if (!val || val.trim() === '') {
    throw new Error(
      `[config] missing required environment variable: ${name}. ` +
        `Copy .env.example to .env and fill it in.`,
    );
  }
  return val;
}

const dataDir = path.resolve(__dirname, '..', 'data');

module.exports = {
  discord: {
    token: required('DISCORD_TOKEN'),
    clientId: required('DISCORD_CLIENT_ID'),
    devGuildId: process.env.DISCORD_DEV_GUILD_ID || null,
  },

  security: {
    // Base64, 32 raw bytes -> AES-256-GCM key. Validated for real shape in
    // utils/crypto.js (fail fast at boot, not on the first encrypt() call).
    encryptionKey: required('ENCRYPTION_KEY'),
  },

  storage: {
    databasePath: process.env.DATABASE_PATH || path.join(dataDir, 'monodeployerexe.db'),
    logDir: process.env.LOG_DIR || path.join(dataDir, 'logs'),
  },

  ownerIds: (process.env.BOT_OWNER_IDS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),

  // --- Branding (build brief section 1) --------------------------------
  // Minimalist, no emojis anywhere, dark neutral + one accent color.
  branding: {
    name: 'MonoDeployerExE',
    developer: 'MonoMusic Development',
    footer: 'MonoDeployerExE — by MonoMusic Development',
    colors: {
      // Dark neutral base for most embeds.
      neutral: 0x1a1c1f,
      // Single accent, used for headers/highlights/success.
      accent: 0x5b8cff,
      warning: 0xd9a441,
      danger: 0xc9524b,
    },
  },

  // --- Execution limits (build brief sections 3, 5, 6) -------------------
  execution: {
    // Backstop timeout for an entire install.sh run, in addition to the
    // per-step run_with_timeout calls already inside each script. Remote
    // SSH sessions get a little more headroom for network variance.
    localTimeoutMs: 15 * 60 * 1000,
    remoteTimeoutMs: 20 * 60 * 1000,
    sshConnectTimeoutMs: 20 * 1000,
    // How often /deploy is allowed to edit its progress message, to stay
    // well under Discord's per-channel edit rate limit.
    progressEditIntervalMs: 2500,
  },
};
