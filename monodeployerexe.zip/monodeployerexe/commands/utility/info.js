const { SlashCommandBuilder } = require('discord.js');
const embeds = require('../../ui/embeds');
const config = require('../../config/config');
const panelManifest = require('../../deploy/panelManifest');

const STATUS_LABEL = {
  ready: 'Ready',
  partial: 'Partial (see /panels)',
  blocked_pending_verification: 'Blocked — pending verification',
  external: 'External installer',
};

module.exports = {
  guildOnly: false,
  data: new SlashCommandBuilder().setName('info').setDescription('About MonoDeployerExE.'),

  async execute(interaction) {
    const panels = panelManifest.listable();
    const panelLines = panels.map((p) => `${p.display_name} — ${STATUS_LABEL[p.status] ?? p.status}`);

    await interaction.reply({
      embeds: [
        embeds.accent({
          title: config.branding.name,
          description:
            'Deploys game/bot hosting panels — locally or to a VPS you provide — inside isolated, ' +
            'resource-capped Docker containers wherever a panel\u2019s official install supports it. ' +
            'Real infrastructure automation: it runs installers with root-level access on real machines.',
          fields: [
            { name: 'Developer', value: config.branding.developer, inline: true },
            { name: 'Package version', value: `v${require('../../package.json').version}`, inline: true },
            { name: 'Supported panels', value: panelLines.join('\n') },
          ],
        }),
      ],
    });
  },
};
