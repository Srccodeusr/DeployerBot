const { SlashCommandBuilder } = require('discord.js');
const helpMenu = require('../../ui/helpMenu');

module.exports = {
  guildOnly: false,
  data: new SlashCommandBuilder().setName('help').setDescription('Browse MonoDeployerExE\u2019s commands by category.'),

  async execute(interaction) {
    await interaction.reply({
      embeds: [helpMenu.landingEmbed()],
      components: [helpMenu.buildMenu()],
    });
  },
};
