const { SlashCommandBuilder } = require('discord.js');
const embeds = require('../../ui/embeds');

module.exports = {
  guildOnly: false,
  data: new SlashCommandBuilder().setName('ping').setDescription('Check the bot\u2019s latency.'),

  async execute(interaction) {
    const sent = await interaction.reply({ content: 'Measuring...', fetchReply: true });
    const roundTrip = sent.createdTimestamp - interaction.createdTimestamp;
    const wsHeartbeat = interaction.client.ws.ping;

    await interaction.editReply({
      content: null,
      embeds: [
        embeds.accent({
          title: 'Pong',
          fields: [
            { name: 'Round trip', value: `${roundTrip}ms`, inline: true },
            { name: 'WebSocket heartbeat', value: `${wsHeartbeat}ms`, inline: true },
          ],
        }),
      ],
    });
  },
};
