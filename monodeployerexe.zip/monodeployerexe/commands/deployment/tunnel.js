// commands/deployment/tunnel.js — build brief section 7: let the user add
// a tunnel later without redeploying anything, or remove one. The token
// goes through a modal, never a slash command option (build brief
// section 8).

const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const deployments = require('../../database/models/deployments');
const targetResolver = require('../../deploy/targetResolver');
const pendingTunnelStore = require('../../deploy/pendingTunnelStore');
const embeds = require('../../ui/embeds');
const { isBotAdmin } = require('../../utils/permissions');
const logger = require('../../utils/logger').create('tunnel');

function ownedDeploymentChoices(interaction) {
  return deployments
    .latestForUser(interaction.guildId, interaction.user.id, 25)
    .filter((d) => d.status === 'success');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tunnel')
    .setDescription('Add or remove a Cloudflare Tunnel for a deployment.')
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Install a Cloudflare Tunnel on a deployment\u2019s target.')
        .addIntegerOption((opt) => opt.setName('deployment-id').setDescription('Which successful deployment').setRequired(true).setAutocomplete(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('Uninstall the Cloudflare Tunnel from a deployment\u2019s target.')
        .addIntegerOption((opt) => opt.setName('deployment-id').setDescription('Which deployment').setRequired(true).setAutocomplete(true)),
    ),

  async autocomplete(interaction) {
    const query = String(interaction.options.getFocused());
    await interaction.respond(
      ownedDeploymentChoices(interaction)
        .filter((d) => String(d.id).includes(query) || d.panel_id.includes(query))
        .map((d) => ({ name: `#${d.id} \u2014 ${d.panel_id}${d.cloudflare_tunnel_installed ? ' (tunnel installed)' : ''}`, value: d.id })),
    );
  },

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const deploymentId = interaction.options.getInteger('deployment-id', true);
    const deployment = deployments.get(deploymentId);

    if (!deployment || deployment.guild_id !== interaction.guildId) {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Not found', description: `No deployment #${deploymentId} in this server.` })], ephemeral: true });
      return;
    }
    if (deployment.user_id !== interaction.user.id && !isBotAdmin(interaction)) {
      await interaction.reply({ content: 'Only the person who ran this deployment (or a bot admin) can manage its tunnel.', ephemeral: true });
      return;
    }
    if (deployment.status !== 'success') {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Deployment not successful', description: 'Tunnels can only be attached to a successfully deployed panel.' })], ephemeral: true });
      return;
    }

    if (sub === 'add') {
      const token = pendingTunnelStore.create({ deploymentId });
      const modal = new ModalBuilder().setCustomId(`tunnel:addSubmit:${token}`).setTitle('Add Cloudflare Tunnel');
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('token').setLabel('Cloudflare Tunnel token').setStyle(TextInputStyle.Paragraph).setRequired(true),
        ),
      );
      await interaction.showModal(modal);
      return;
    }

    // remove
    await interaction.deferReply({ ephemeral: true });
    try {
      const { executor } = targetResolver.resolve(deployment.target_type, deployment.vps_profile_id);
      const { exitCode } = await executor.runRaw('cloudflared service uninstall', { timeoutMs: 30000, onLine: () => {} });
      await executor.disconnect?.();
      if (exitCode === 0) {
        await interaction.editReply({ embeds: [embeds.success({ title: 'Tunnel removed', description: `Cloudflare Tunnel uninstalled from deployment #${deployment.id}\u2019s target.` })] });
      } else {
        await interaction.editReply({ embeds: [embeds.warning({ title: 'Uninstall reported an issue', description: `cloudflared exited with code ${exitCode} \u2014 it may not have been installed.` })] });
      }
    } catch (err) {
      logger.error(`tunnel remove failed for deployment ${deployment.id}`, err);
      await interaction.editReply({ embeds: [embeds.danger({ title: 'Could not remove tunnel', description: err.message })] });
    }
  },
};
