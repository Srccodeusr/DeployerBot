// commands/deployment/panels.js — build brief section 4: lists every
// panel from lib/panels.json with what it needs, docker vs native, and
// current status — surfacing the status_note/verification_note for
// partial/blocked panels so the caveat is visible before someone tries to
// deploy, not discovered after.

const { SlashCommandBuilder } = require('discord.js');
const panelManifest = require('../../deploy/panelManifest');
const guildConfig = require('../../database/models/guildConfig');
const embeds = require('../../ui/embeds');

const STATUS_LABEL = {
  ready: 'Ready',
  partial: 'Partial',
  blocked_pending_verification: 'Blocked \u2014 pending verification',
  external: 'External installer',
};

function formatPanel(panel, enabledForGuild) {
  const lines = [];
  lines.push(`**${panel.display_name}** \u2014 ${STATUS_LABEL[panel.status] ?? panel.status}${enabledForGuild === false ? ' (disabled here)' : ''}`);
  if (panel.script) {
    lines.push(`Mode: ${panel.mode}`);
    const required = panel.required_flags?.length ? panel.required_flags.map((f) => `\`${f}\``).join(', ') : 'none';
    const optional = panel.optional_flags?.length ? panel.optional_flags.map((f) => `\`${f}\``).join(', ') : 'none';
    lines.push(`Required: ${required}`);
    lines.push(`Optional: ${optional}`);
  } else {
    lines.push(`Mode: ${panel.mode} (not wired through this bot's \`lib/\` \u2014 uses its own official installer)`);
  }
  const note = panel.status_note || panel.verification_note;
  if (note) lines.push(`Note: ${note}`);
  return lines.join('\n');
}

module.exports = {
  data: new SlashCommandBuilder().setName('panels').setDescription('List supported panels, requirements, and current status.'),

  async execute(interaction) {
    const panels = panelManifest.listable();
    const cfg = interaction.inGuild() ? guildConfig.get(interaction.guildId) : { enabled_panel_ids: null };
    const enabledSet = cfg.enabled_panel_ids ? new Set(cfg.enabled_panel_ids) : null;

    const blocks = panels.map((p) => {
      const enabledForGuild = !enabledSet || p.status === 'external' ? undefined : enabledSet.has(p.id);
      return formatPanel(p, enabledForGuild);
    });

    await interaction.reply({
      embeds: [
        embeds.accent({
          title: 'Supported panels',
          description: blocks.join('\n\n'),
        }),
      ],
    });
  },
};
