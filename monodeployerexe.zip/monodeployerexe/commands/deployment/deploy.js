// commands/deployment/deploy.js — build brief section 4's core command.
//
// Deliberately keeps secret-shaped values (admin password override,
// Cloudflare tunnel token, mail credentials) OUT of slash command options:
// Discord renders a command's option values in the channel as part of the
// interaction, which would be "echoing" a secret into Discord in exactly
// the way section 8 prohibits. Those go through the "Advanced options"
// modal instead (interactions/modals/deployAdvancedModal.js), which is
// not rendered as visible message content.
//
// Remote deploys require a saved /vps profile rather than accepting raw
// host/username/password here for the same reason.

const { SlashCommandBuilder } = require('discord.js');
const panelManifest = require('../../deploy/panelManifest');
const pendingDeployStore = require('../../deploy/pendingDeployStore');
const guildConfig = require('../../database/models/guildConfig');
const vpsProfiles = require('../../database/models/vpsProfiles');
const validators = require('../../utils/validators');
const embeds = require('../../ui/embeds');
const components = require('../../ui/components');
const { buildFlagsForPanel } = require('../../deploy/flagBuilder');

const STATUS_CAVEAT = {
  partial: (p) => p.status_note ?? 'This panel deploys with one manual follow-up step \u2014 see /panels.',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('deploy')
    .setDescription('Deploy a hosting panel, locally or to a saved VPS.')
    .addStringOption((opt) =>
      opt.setName('panel').setDescription('Which panel to deploy').setRequired(true).setAutocomplete(true),
    )
    .addStringOption((opt) =>
      opt
        .setName('target')
        .setDescription('Where to deploy it')
        .setRequired(true)
        .addChoices(
          { name: 'Local (this machine)', value: 'local' },
          { name: 'Remote (saved VPS profile)', value: 'remote' },
        ),
    )
    .addStringOption((opt) =>
      opt
        .setName('vps-profile')
        .setDescription('Saved VPS profile (required for remote target)')
        .setAutocomplete(true),
    )
    .addStringOption((opt) => opt.setName('domain').setDescription('Domain the panel will be served on'))
    .addStringOption((opt) => opt.setName('email').setDescription('Admin email (required by some panels)'))
    .addStringOption((opt) => opt.setName('admin-user').setDescription('Admin username (default: admin)'))
    .addNumberOption((opt) => opt.setName('cpu-limit').setDescription('CPU cores to cap the deployment at'))
    .addStringOption((opt) => opt.setName('mem-limit').setDescription('Memory cap, e.g. 2g or 512m')),

  async autocomplete(interaction) {
    const focused = interaction.options.getFocused(true);
    if (focused.name === 'panel') {
      const config = guildConfig.get(interaction.guildId);
      const panels = panelManifest.deployableForGuild(config.enabled_panel_ids);
      const query = focused.value.toLowerCase();
      const choices = panels
        .filter((p) => p.display_name.toLowerCase().includes(query))
        .slice(0, 25)
        .map((p) => ({ name: p.display_name, value: p.id }));
      await interaction.respond(choices);
      return;
    }
    if (focused.name === 'vps-profile') {
      const profiles = vpsProfiles.listForUser(interaction.guildId, interaction.user.id);
      const query = focused.value.toLowerCase();
      const choices = profiles
        .filter((p) => p.name.toLowerCase().includes(query))
        .slice(0, 25)
        .map((p) => ({ name: `${p.name} (${p.username}@${p.host})`, value: p.name }));
      await interaction.respond(choices);
    }
  },

  async execute(interaction) {
    const panelId = interaction.options.getString('panel', true);
    const target = interaction.options.getString('target', true);
    const vpsProfileName = interaction.options.getString('vps-profile');
    const domain = interaction.options.getString('domain');
    const email = interaction.options.getString('email');
    const adminUser = interaction.options.getString('admin-user');
    const cpuLimit = interaction.options.getNumber('cpu-limit');
    const memLimit = interaction.options.getString('mem-limit');

    const cfg = guildConfig.get(interaction.guildId);
    const panel = panelManifest.byId(panelId);

    if (!panel || !panelManifest.deployableForGuild(cfg.enabled_panel_ids).some((p) => p.id === panelId)) {
      await interaction.reply({
        embeds: [
          embeds.danger({
            title: 'Panel not available',
            description:
              `\`${panelId}\` isn\u2019t currently selectable. It may be pending verification, external-only, ` +
              'or disabled for this server \u2014 check `/panels`.',
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    if (target === 'local' && !cfg.allow_local_target) {
      await interaction.reply({
        embeds: [embeds.danger({ title: 'Local deploys disabled', description: 'An admin has disabled local deploys for this server.' })],
        ephemeral: true,
      });
      return;
    }
    if (target === 'remote' && !cfg.allow_remote_target) {
      await interaction.reply({
        embeds: [embeds.danger({ title: 'Remote deploys disabled', description: 'An admin has disabled remote deploys for this server.' })],
        ephemeral: true,
      });
      return;
    }

    let vpsProfile = null;
    if (target === 'remote') {
      if (!vpsProfileName) {
        await interaction.reply({
          embeds: [
            embeds.danger({
              title: 'VPS profile required',
              description: 'Remote deploys need a saved profile \u2014 pick one with the `vps-profile` option, or run `/vps add` first.',
            }),
          ],
          ephemeral: true,
        });
        return;
      }
      vpsProfile = vpsProfiles.findByName(interaction.guildId, interaction.user.id, vpsProfileName);
      if (!vpsProfile) {
        await interaction.reply({
          embeds: [embeds.danger({ title: 'VPS profile not found', description: `No saved profile named \`${vpsProfileName}\`. Check \`/vps list\`.` })],
          ephemeral: true,
        });
        return;
      }
    }

    if (domain && !validators.isValidDomain(domain)) {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Invalid domain', description: `\`${domain}\` doesn\u2019t look like a valid domain.` })], ephemeral: true });
      return;
    }
    if (email && !validators.isValidEmail(email)) {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Invalid email', description: `\`${email}\` doesn\u2019t look like a valid email.` })], ephemeral: true });
      return;
    }
    if (cpuLimit !== null && !validators.isValidCpuLimit(cpuLimit)) {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Invalid cpu-limit', description: 'Must be a number between 0 and 32.' })], ephemeral: true });
      return;
    }
    if (memLimit && !validators.isValidMemLimit(memLimit)) {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Invalid mem-limit', description: 'Use Compose shorthand, e.g. `512m` or `2g`.' })], ephemeral: true });
      return;
    }

    const candidateFlags = {
      domain,
      email,
      'admin-user': adminUser,
      'cpu-limit': cpuLimit ?? undefined,
      'mem-limit': memLimit,
    };
    const { flags, missingRequired } = buildFlagsForPanel(panelId, candidateFlags);

    if (missingRequired.length) {
      await interaction.reply({
        embeds: [
          embeds.danger({
            title: 'Missing required option(s)',
            description: `${panel.display_name} needs: ${missingRequired.map((f) => `\`${f}\``).join(', ')}`,
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    const token = pendingDeployStore.create({
      panelId,
      panel,
      target,
      vpsProfileId: vpsProfile?.id ?? null,
      vpsProfileLabel: vpsProfile ? `${vpsProfile.name} (${vpsProfile.username}@${vpsProfile.host})` : null,
      flags,
      advancedFlags: {},
      userId: interaction.user.id,
      guildId: interaction.guildId,
      channelId: interaction.channelId,
    });

    const caveat = STATUS_CAVEAT[panel.status]?.(panel);
    const fields = [
      { name: 'Panel', value: panel.display_name, inline: true },
      { name: 'Target', value: target === 'local' ? 'This machine' : vpsProfile.name, inline: true },
      { name: 'Mode', value: panel.mode, inline: true },
      {
        name: 'Flags',
        value: Object.entries(flags).map(([k, v]) => `\`--${k}=${v}\``).join(' ') || '(none set \u2014 panel defaults apply)',
      },
    ];
    if (caveat) fields.push({ name: 'Before you deploy', value: caveat });

    await interaction.reply({
      embeds: [
        embeds.accent({
          title: 'Confirm deployment',
          description:
            'Review the settings below. **Advanced options** lets you set an admin password override, ' +
            'a Cloudflare Tunnel token, or mail settings \u2014 those aren\u2019t asked for here so they never ' +
            'appear as plain text in this channel.',
          fields,
        }),
      ],
      components: [components.advancedOptionsRow({ token })],
    });
  },
};
