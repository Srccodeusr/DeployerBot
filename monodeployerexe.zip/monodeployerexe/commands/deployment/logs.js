// commands/deployment/logs.js — build brief section 4: "retrieve the full
// raw output for a past deployment." Served as a file attachment rather
// than pasted inline since installs run long and can produce a lot of
// output; the log itself already has secret-shaped RESULT_ values redacted
// at write time (see deploy/deployRunner.js) so this is safe to hand out
// to anyone who can see the deployment record.

const fs = require('node:fs');
const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const deployments = require('../../database/models/deployments');
const embeds = require('../../ui/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('logs')
    .setDescription('Retrieve the full log for a past deployment.')
    .addIntegerOption((opt) => opt.setName('deployment-id').setDescription('Which deployment (default: your most recent)').setAutocomplete(true)),

  async autocomplete(interaction) {
    const recent = deployments.latestForUser(interaction.guildId, interaction.user.id, 25);
    const query = String(interaction.options.getFocused());
    await interaction.respond(
      recent
        .filter((d) => String(d.id).includes(query) || d.panel_id.includes(query))
        .map((d) => ({ name: `#${d.id} \u2014 ${d.panel_id} \u2014 ${d.status}`, value: d.id })),
    );
  },

  async execute(interaction) {
    const deploymentId = interaction.options.getInteger('deployment-id');
    let deployment;
    if (deploymentId) {
      deployment = deployments.get(deploymentId);
      if (!deployment || deployment.guild_id !== interaction.guildId) {
        await interaction.reply({ embeds: [embeds.danger({ title: 'Not found', description: `No deployment #${deploymentId} in this server.` })], ephemeral: true });
        return;
      }
    } else {
      [deployment] = deployments.latestForUser(interaction.guildId, interaction.user.id, 1);
      if (!deployment) {
        await interaction.reply({ embeds: [embeds.base({ title: 'No deployments yet', description: 'Run `/deploy` first.' })], ephemeral: true });
        return;
      }
    }

    if (!deployment.log_file || !fs.existsSync(deployment.log_file)) {
      await interaction.reply({ embeds: [embeds.warning({ title: 'No log available', description: `Deployment #${deployment.id} has no stored log (it may have crashed before logging started).` })], ephemeral: true });
      return;
    }

    const attachment = new AttachmentBuilder(deployment.log_file, { name: `deployment-${deployment.id}-${deployment.panel_id}.log` });
    await interaction.reply({
      embeds: [embeds.accent({ title: `Log for deployment #${deployment.id}`, description: `${deployment.panel_id} \u2014 ${deployment.status}` })],
      files: [attachment],
      ephemeral: true,
    });
  },
};
