// commands/deployment/uninstall.js — build brief section 4: destructive,
// so it always shows a confirm/cancel prompt before touching anything.

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const deployments = require('../../database/models/deployments');
const panelManifest = require('../../deploy/panelManifest');
const embeds = require('../../ui/embeds');
const { isBotAdmin } = require('../../utils/permissions');

function confirmRow(deploymentId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`uninstall:confirm:${deploymentId}`).setLabel('Uninstall').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`uninstall:cancel:${deploymentId}`).setLabel('Cancel').setStyle(ButtonStyle.Secondary),
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('uninstall')
    .setDescription('Remove a previously deployed panel. Destructive — asks for confirmation.')
    .addIntegerOption((opt) => opt.setName('deployment-id').setDescription('Which successful deployment to remove').setRequired(true).setAutocomplete(true)),

  async autocomplete(interaction) {
    const recent = deployments.latestForUser(interaction.guildId, interaction.user.id, 25).filter((d) => d.status === 'success');
    const query = String(interaction.options.getFocused());
    await interaction.respond(
      recent
        .filter((d) => String(d.id).includes(query) || d.panel_id.includes(query))
        .map((d) => ({ name: `#${d.id} \u2014 ${d.panel_id} \u2014 ${d.host_label}`, value: d.id })),
    );
  },

  async execute(interaction) {
    const deploymentId = interaction.options.getInteger('deployment-id', true);
    const deployment = deployments.get(deploymentId);

    if (!deployment || deployment.guild_id !== interaction.guildId) {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Not found', description: `No deployment #${deploymentId} in this server.` })], ephemeral: true });
      return;
    }
    if (deployment.user_id !== interaction.user.id && !isBotAdmin(interaction)) {
      await interaction.reply({ content: 'Only the person who ran this deployment (or a bot admin) can uninstall it.', ephemeral: true });
      return;
    }
    if (deployment.status !== 'success' || !deployment.install_dir) {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Nothing to uninstall', description: 'This deployment doesn\u2019t have a recorded install location (it may not have completed successfully).' })], ephemeral: true });
      return;
    }

    const panel = panelManifest.byId(deployment.panel_id);
    await interaction.reply({
      embeds: [
        embeds.warning({
          title: `Uninstall ${panel?.display_name ?? deployment.panel_id}?`,
          description:
            `This will stop and remove everything at \`${deployment.install_dir}\` on **${deployment.host_label}**, ` +
            `${panel?.mode === 'docker' ? 'including its containers and volumes (databases included).' : 'including its database and system service.'} ` +
            'This cannot be undone.',
        }),
      ],
      components: [confirmRow(deploymentId)],
      ephemeral: true,
    });
  },
};
