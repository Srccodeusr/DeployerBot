// commands/deployment/status.js — build brief section 4: "check the
// status of a past deployment, or live-check whether a deployed panel is
// currently reachable." Deliberately never re-displays the admin password
// (build brief section 8) regardless of whether it was revealed before.

const { SlashCommandBuilder } = require('discord.js');
const deployments = require('../../database/models/deployments');
const targetResolver = require('../../deploy/targetResolver');
const embeds = require('../../ui/embeds');
const logger = require('../../utils/logger').create('status');

const STATUS_LABEL = {
  running: 'Running',
  success: 'Success',
  failed: 'Failed',
  blocked: 'Blocked (pending verification)',
  aborted: 'Aborted (routing mismatch)',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Check a past deployment, optionally with a live reachability check.')
    .addIntegerOption((opt) => opt.setName('deployment-id').setDescription('Which deployment (default: your most recent)').setAutocomplete(true))
    .addBooleanOption((opt) => opt.setName('live-check').setDescription('Also check whether the panel currently responds')),

  async autocomplete(interaction) {
    const recent = deployments.latestForUser(interaction.guildId, interaction.user.id, 25);
    const query = String(interaction.options.getFocused());
    await interaction.respond(
      recent
        .filter((d) => String(d.id).includes(query) || d.panel_id.includes(query))
        .map((d) => ({ name: `#${d.id} \u2014 ${d.panel_id} \u2014 ${d.status}`, value: d.id })),
    );
  },

  async execute(interaction) {
    const deploymentId = interaction.options.getInteger('deployment-id');
    const liveCheck = interaction.options.getBoolean('live-check') ?? false;

    let deployment;
    if (deploymentId) {
      deployment = deployments.get(deploymentId);
      if (!deployment || deployment.guild_id !== interaction.guildId) {
        await interaction.reply({ embeds: [embeds.danger({ title: 'Not found', description: `No deployment #${deploymentId} in this server.` })], ephemeral: true });
        return;
      }
    } else {
      [deployment] = deployments.latestForUser(interaction.guildId, interaction.user.id, 1);
      if (!deployment) {
        await interaction.reply({ embeds: [embeds.base({ title: 'No deployments yet', description: 'Run `/deploy` first.' })], ephemeral: true });
        return;
      }
    }

    const fields = [
      { name: 'Panel', value: deployment.panel_id, inline: true },
      { name: 'Status', value: STATUS_LABEL[deployment.status] ?? deployment.status, inline: true },
      { name: 'Target', value: deployment.host_label ?? deployment.target_type, inline: true },
      { name: 'Started', value: `<t:${Math.floor(new Date(deployment.started_at).getTime() / 1000)}:R>`, inline: true },
    ];
    if (deployment.finished_at) fields.push({ name: 'Finished', value: `<t:${Math.floor(new Date(deployment.finished_at).getTime() / 1000)}:R>`, inline: true });
    if (deployment.result_url) fields.push({ name: 'URL', value: deployment.result_url });
    if (deployment.result_admin_user) fields.push({ name: 'Admin user', value: deployment.result_admin_user, inline: true });
    if (deployment.encrypted_admin_password) {
      fields.push({
        name: 'Admin password',
        value: deployment.admin_password_revealed ? 'Already revealed once \u2014 not shown again here. Reset via the panel if lost.' : 'Not yet revealed \u2014 see the original /deploy completion message.',
        inline: true,
      });
    }
    if (deployment.cloudflare_tunnel_installed) fields.push({ name: 'Cloudflare Tunnel', value: 'Installed' });
    if (deployment.error_message) fields.push({ name: 'Error', value: deployment.error_message });

    const color = deployment.status === 'success' ? 'success' : deployment.status === 'failed' || deployment.status === 'aborted' ? 'danger' : 'warning';

    if (!liveCheck) {
      await interaction.reply({ embeds: [embeds[color]({ title: `Deployment #${deployment.id}`, fields })] });
      return;
    }

    await interaction.deferReply();
    let liveResult = 'No URL recorded for this deployment \u2014 nothing to check.';
    if (deployment.result_url) {
      try {
        const { executor } = targetResolver.resolve(deployment.target_type, deployment.vps_profile_id);
        const { exitCode } = await executor.runRaw(
          `curl -s -o /dev/null -w '%{http_code}' --max-time 10 '${deployment.result_url.replace(/'/g, "'\\''")}'`,
          { timeoutMs: 15000, onLine: () => {} },
        );
        await executor.disconnect?.();
        liveResult = exitCode === 0 ? 'Responded to a request just now.' : `curl exited with code ${exitCode} \u2014 likely unreachable right now.`;
      } catch (err) {
        logger.warn(`live-check failed for deployment ${deployment.id}`, err.message);
        liveResult = `Could not check \u2014 ${err.message}`;
      }
    }
    fields.push({ name: 'Live check', value: liveResult });

    await interaction.editReply({ embeds: [embeds[color]({ title: `Deployment #${deployment.id}`, fields })] });
  },
};
