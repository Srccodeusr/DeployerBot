// commands/deployment/vps.js — build brief section 4: "add / list / remove
// saved VPS connection profiles, so a user doesn't re-enter SSH details on
// every deploy. Profiles are per-user."
//
// The secret (password or private key) is never a slash command option —
// `add` collects host/port/username/auth-method as options, then opens a
// modal for the secret itself, same reasoning as /deploy's advanced-options
// modal (build brief section 8: never echo credentials into Discord).

const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const vpsProfiles = require('../../database/models/vpsProfiles');
const pendingVpsStore = require('../../deploy/pendingVpsStore');
const validators = require('../../utils/validators');
const embeds = require('../../ui/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vps')
    .setDescription('Manage saved VPS connection profiles.')
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Save a new VPS connection profile.')
        .addStringOption((opt) => opt.setName('name').setDescription('Short name for this profile, e.g. "main-box"').setRequired(true))
        .addStringOption((opt) => opt.setName('host').setDescription('Hostname or IP').setRequired(true))
        .addStringOption((opt) => opt.setName('username').setDescription('SSH username').setRequired(true))
        .addStringOption((opt) =>
          opt
            .setName('auth-method')
            .setDescription('How to authenticate')
            .setRequired(true)
            .addChoices({ name: 'Password', value: 'password' }, { name: 'Private key', value: 'private-key' }),
        )
        .addIntegerOption((opt) => opt.setName('port').setDescription('SSH port (default 22)').setMinValue(1).setMaxValue(65535)),
    )
    .addSubcommand((sub) => sub.setName('list').setDescription('List your saved VPS profiles.'))
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('Delete a saved VPS profile.')
        .addStringOption((opt) => opt.setName('name').setDescription('Profile to remove').setRequired(true).setAutocomplete(true)),
    ),

  async autocomplete(interaction) {
    const focused = interaction.options.getFocused(true);
    if (focused.name !== 'name') return;
    const profiles = vpsProfiles.listForUser(interaction.guildId, interaction.user.id);
    const query = focused.value.toLowerCase();
    await interaction.respond(
      profiles
        .filter((p) => p.name.toLowerCase().includes(query))
        .slice(0, 25)
        .map((p) => ({ name: `${p.name} (${p.username}@${p.host})`, value: p.name })),
    );
  },

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const name = interaction.options.getString('name', true).trim();
      const host = interaction.options.getString('host', true).trim();
      const username = interaction.options.getString('username', true).trim();
      const authMethod = interaction.options.getString('auth-method', true);
      const port = interaction.options.getInteger('port') ?? 22;

      if (!/^[a-zA-Z0-9._-]{1,32}$/.test(name)) {
        await interaction.reply({ embeds: [embeds.danger({ title: 'Invalid name', description: 'Use 1\u201332 letters, numbers, dots, dashes, or underscores.' })], ephemeral: true });
        return;
      }
      if (!validators.isValidPort(port)) {
        await interaction.reply({ embeds: [embeds.danger({ title: 'Invalid port', description: 'Port must be between 1 and 65535.' })], ephemeral: true });
        return;
      }
      if (vpsProfiles.findByName(interaction.guildId, interaction.user.id, name)) {
        await interaction.reply({ embeds: [embeds.danger({ title: 'Name already in use', description: `You already have a profile named \`${name}\`. Remove it first or pick another name.` })], ephemeral: true });
        return;
      }

      const token = pendingVpsStore.create({
        guildId: interaction.guildId,
        userId: interaction.user.id,
        name,
        host,
        port,
        username,
        authMethod,
      });

      const modal = new ModalBuilder().setCustomId(`vps:addSubmit:${token}`).setTitle(`Add VPS profile: ${name}`);
      if (authMethod === 'password') {
        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('secret').setLabel('SSH password').setStyle(TextInputStyle.Short).setRequired(true),
          ),
        );
      } else {
        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('secret').setLabel('Private key (PEM contents)').setStyle(TextInputStyle.Paragraph).setRequired(true),
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('passphrase').setLabel('Passphrase (optional)').setStyle(TextInputStyle.Short).setRequired(false),
          ),
        );
      }
      await interaction.showModal(modal);
      return;
    }

    if (sub === 'list') {
      const profiles = vpsProfiles.listForUser(interaction.guildId, interaction.user.id);
      if (!profiles.length) {
        await interaction.reply({ embeds: [embeds.base({ title: 'No saved VPS profiles', description: 'Add one with `/vps add`.' })], ephemeral: true });
        return;
      }
      await interaction.reply({
        embeds: [
          embeds.accent({
            title: 'Your saved VPS profiles',
            description: profiles
              .map((p) => `**${p.name}** \u2014 ${p.username}@${p.host}:${p.port} (${p.auth_method})`)
              .join('\n'),
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    if (sub === 'remove') {
      const name = interaction.options.getString('name', true);
      const profile = vpsProfiles.findByName(interaction.guildId, interaction.user.id, name);
      if (!profile) {
        await interaction.reply({ embeds: [embeds.danger({ title: 'Not found', description: `No saved profile named \`${name}\`.` })], ephemeral: true });
        return;
      }
      vpsProfiles.removeByName(interaction.guildId, interaction.user.id, name);
      await interaction.reply({ embeds: [embeds.success({ title: 'Profile removed', description: `\`${name}\` has been deleted.` })], ephemeral: true });
    }
  },
};
