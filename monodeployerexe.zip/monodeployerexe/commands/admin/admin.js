// commands/admin/admin.js — build brief section 4's admin surface: 3-5
// sensible subcommands, permission-gated via utils/permissions.js to
// server admins or a configurable bot-admin role, not hardcoded to the
// bot owner.

const { SlashCommandBuilder } = require('discord.js');
const guildConfig = require('../../database/models/guildConfig');
const vpsProfiles = require('../../database/models/vpsProfiles');
const auditLog = require('../../database/models/auditLog');
const panelManifest = require('../../deploy/panelManifest');
const embeds = require('../../ui/embeds');
const components = require('../../ui/components');
const { isBotAdmin } = require('../../utils/permissions');

const { ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin')
    .setDescription('Server configuration and audit log for MonoDeployerExE.')
    .setDefaultMemberPermissions(null) // gate is applied in execute() via isBotAdmin, not Discord's own permission system alone
    .addSubcommand((sub) =>
      sub
        .setName('role')
        .setDescription('Set the bot-admin role for this server.')
        .addRoleOption((opt) => opt.setName('role').setDescription('Role to treat as bot-admin (omit to clear)')),
    )
    .addSubcommand((sub) => sub.setName('panels').setDescription('Choose which panels are enabled in this server.'))
    .addSubcommand((sub) =>
      sub
        .setName('targets')
        .setDescription('Enable or disable local/remote deploy targets for this server.')
        .addBooleanOption((opt) => opt.setName('local').setDescription('Allow local deploys'))
        .addBooleanOption((opt) => opt.setName('remote').setDescription('Allow remote (VPS) deploys')),
    )
    .addSubcommand((sub) =>
      sub
        .setName('credentials')
        .setDescription('View, or revoke, saved VPS profiles in this server.')
        .addStringOption((opt) => opt.setName('revoke').setDescription('Profile to revoke (leave blank to just list)').setAutocomplete(true)),
    )
    .addSubcommand((sub) => sub.setName('audit').setDescription('View the deployment and admin-action history.')),

  async autocomplete(interaction) {
    const focused = interaction.options.getFocused(true);
    if (focused.name !== 'revoke') return;
    const profiles = vpsProfiles.listForGuild(interaction.guildId);
    const query = focused.value.toLowerCase();
    await interaction.respond(
      profiles
        .filter((p) => p.name.toLowerCase().includes(query))
        .slice(0, 25)
        .map((p) => ({ name: `${p.name} \u2014 <@${p.user_id}> (${p.username}@${p.host})`.slice(0, 100), value: String(p.id) })),
    );
  },

  async execute(interaction) {
    if (!isBotAdmin(interaction)) {
      await interaction.reply({ embeds: [embeds.danger({ title: 'Not allowed', description: 'This requires server admin, Manage Server, or the configured bot-admin role.' })], ephemeral: true });
      return;
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'role') {
      const role = interaction.options.getRole('role');
      guildConfig.setAdminRole(interaction.guildId, role?.id ?? null);
      auditLog.record({ guildId: interaction.guildId, actorId: interaction.user.id, action: 'admin_set_role', target: role?.id ?? null });
      await interaction.reply({ embeds: [embeds.success({ title: 'Bot-admin role updated', description: role ? `${role} can now use /admin commands.` : 'Cleared \u2014 only server admins/Manage Server can use /admin now.' })], ephemeral: true });
      return;
    }

    if (sub === 'panels') {
      const cfg = guildConfig.get(interaction.guildId);
      const deployablePanels = panelManifest.deployable();
      const selected = cfg.enabled_panel_ids ?? deployablePanels.map((p) => p.id);

      const menu = new StringSelectMenuBuilder()
        .setCustomId('admin:panelsToggle')
        .setPlaceholder('Choose which panels are enabled\u2026')
        .setMinValues(0)
        .setMaxValues(deployablePanels.length)
        .addOptions(deployablePanels.map((p) => ({ label: p.display_name, value: p.id, default: selected.includes(p.id) })));

      await interaction.reply({
        embeds: [embeds.accent({ title: 'Enabled panels', description: 'Panels left unchecked won\u2019t be selectable in `/deploy` for this server.' })],
        components: [new ActionRowBuilder().addComponents(menu)],
        ephemeral: true,
      });
      return;
    }

    if (sub === 'targets') {
      const local = interaction.options.getBoolean('local');
      const remote = interaction.options.getBoolean('remote');
      const cfg = guildConfig.get(interaction.guildId);
      const next = { local: local ?? cfg.allow_local_target, remote: remote ?? cfg.allow_remote_target };
      guildConfig.setTargetsAllowed(interaction.guildId, next);
      auditLog.record({ guildId: interaction.guildId, actorId: interaction.user.id, action: 'admin_set_targets', details: next });
      await interaction.reply({ embeds: [embeds.success({ title: 'Targets updated', description: `Local: ${next.local ? 'allowed' : 'disabled'}. Remote: ${next.remote ? 'allowed' : 'disabled'}.` })], ephemeral: true });
      return;
    }

    if (sub === 'credentials') {
      const revokeId = interaction.options.getString('revoke');
      if (revokeId) {
        const profile = vpsProfiles.findById(Number(revokeId));
        if (!profile || profile.guild_id !== interaction.guildId) {
          await interaction.reply({ embeds: [embeds.danger({ title: 'Not found', description: 'That profile no longer exists.' })], ephemeral: true });
          return;
        }
        vpsProfiles.remove(profile.id);
        auditLog.record({ guildId: interaction.guildId, actorId: interaction.user.id, action: 'admin_revoke_credential', target: profile.name, details: { owner: profile.user_id } });
        await interaction.reply({ embeds: [embeds.success({ title: 'Profile revoked', description: `\`${profile.name}\` (owned by <@${profile.user_id}>) has been deleted.` })], ephemeral: true });
        return;
      }

      const profiles = vpsProfiles.listForGuild(interaction.guildId);
      await interaction.reply({
        embeds: [
          embeds.accent({
            title: 'Saved VPS profiles in this server',
            description: profiles.length
              ? profiles.map((p) => `**${p.name}** \u2014 <@${p.user_id}> \u2014 ${p.username}@${p.host}:${p.port} (${p.auth_method})`).join('\n')
              : 'None saved yet.',
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    if (sub === 'audit') {
      const entries = auditLog.list(interaction.guildId, 15);
      await interaction.reply({
        embeds: [
          embeds.accent({
            title: 'Recent activity',
            description: entries.length
              ? entries.map((e) => `<t:${Math.floor(new Date(e.created_at).getTime() / 1000)}:R> \u2014 <@${e.actor_id}> \u2014 **${e.action}**${e.target ? ` \u2192 ${e.target}` : ''}`).join('\n')
              : 'No recorded activity yet.',
          }),
        ],
        ephemeral: true,
      });
    }
  },
};
