# MonoDeployerExE

A Discord bot, by MonoMusic Development, that deploys game/bot hosting
panels — locally or to a VPS you provide — inside isolated,
resource-capped Docker containers wherever a panel's official install
supports it. This is real infrastructure automation: it runs installer
scripts with root-level access on real machines. Treat it with the same
care you'd give any tool that can `rm -rf` a server.

## What's included

```
monodeployerexe/
├── lib/                    # the installer library (bundled, unmodified)
│   ├── common/lib.sh        # shared bash helpers (logging, flag parsing, gen_secret, ...)
│   ├── panels.json           # source of truth for what's deployable and what it needs
│   ├── pterodactyl/install.sh
│   ├── jexactyl/install.sh
│   ├── reviactyl/install.sh
│   ├── convoy/install.sh
│   └── mythicaldash/install.sh
├── executors/               # local (child_process) + remote (ssh2) execution, one shared interface
├── deploy/                  # orchestration: manifest loading, flag building, the STEP/RESULT_ parser,
│                             # progress reporting, tunnel install, uninstall teardown
├── database/                 # SQLite (better-sqlite3): guild config, VPS profiles, deployment
│                             # history, audit log — secrets encrypted with AES-256-GCM
├── commands/                 # slash commands (utility, deployment, admin)
├── interactions/              # buttons, select menus, modals, routed by customId
├── ui/                        # branded embeds + reusable components
├── handlers/, events/         # command/event/interaction loading and dispatch
├── index.js                   # bot entry point
└── deploy-commands.js          # one-off script to register slash commands with Discord
```

## Setup

1. `npm install`
2. Copy `.env.example` to `.env` and fill in:
   - `DISCORD_TOKEN`, `DISCORD_CLIENT_ID` from the Discord Developer Portal.
   - `ENCRYPTION_KEY` — generate with:
     ```
     node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
     ```
     This encrypts every VPS credential, Cloudflare Tunnel token, and generated
     admin password at rest. **Losing it makes every stored credential
     permanently unrecoverable — there is no fallback.** Back it up somewhere
     separate from the database file.
   - `BOT_OWNER_IDS` (optional) — comma-separated Discord user IDs that can
     always use `/admin`, even in a guild that hasn't set a bot-admin role yet.
3. Register commands: `npm run deploy-commands:guild` (instant, needs
   `DISCORD_DEV_GUILD_ID`) while developing, or `npm run deploy-commands`
   for a global rollout once you're happy with it.
4. `npm start`

The bot needs to run somewhere with the privileges to actually do what
you ask it to do: root (or passwordless sudo wired in out of band) for
local deploys, since the installers call `apt-get`, manage Docker, and
write to `/etc`. It does not attempt to silently elevate its own
privileges.

## How a deploy works

`/deploy` collects the panel, target, and non-secret flags (domain,
email, admin-user, cpu-limit, mem-limit) as slash command options, then
shows a confirm screen with an **Advanced options** button. Anything
secret-shaped — an admin password override, a Cloudflare Tunnel token, or
mail credentials — goes through that modal instead of a visible slash
command option, since Discord renders command option values in the
channel and that would defeat the point of encrypting them at rest.

Once confirmed, the bot picks a local or remote executor (remote requires
a profile saved via `/vps add` — SSH details are never typed directly
into `/deploy`), runs the matching `lib/<panel>/install.sh`, and streams
`STEP:`/`OK:`/`WARN:` lines back as periodic message edits (not raw
output — Discord rate-limits edits). It checks the script's own
`PANEL_ID:` announcement against what was requested and hard-aborts if
they don't match, since that specific failure mode (a routing bug handing
back a *working panel that isn't the one you asked for*) would otherwise
look identical to success.

On success, a generated admin password is shown exactly once via a
"Reveal" button and never re-displayed by `/status` or `/logs` afterward
— reset it through the panel's own admin tools if it's lost. The full raw
log is saved per-deployment (with any password/token-shaped `RESULT_`
line redacted before it's ever written to disk) and retrievable via
`/logs`.

## Panel status, honestly

Pulled straight from `lib/panels.json` — check `/panels` in Discord for
the live version:

| Panel | Mode | Status |
|---|---|---|
| Pterodactyl | Docker | Ready — official image, verified compose path |
| Jexactyl | Docker | Ready — verified against the official compose file |
| Reviactyl | Native (scoped system user, not root) | Ready — no official Docker path exists yet |
| Convoy | Docker | Partial — deploys, but non-interactive admin-user creation isn't automated; needs manual follow-up (see the WARN output) |
| MythicalDash | Docker | **Blocked** — refuses to run (exits 3) until its compose file is independently verified; see the TODO in `lib/mythicaldash/install.sh` |
| Airlink | Native/hybrid | External — intentionally not wired into this bot; run its own official installer directly |

## Security notes

- VPS SSH credentials, Cloudflare Tunnel tokens, and generated admin
  passwords are AES-256-GCM encrypted at rest with `ENCRYPTION_KEY`.
- Nothing secret-shaped is ever passed as a slash command option — see
  "How a deploy works" above.
- `/admin credentials` lets a server admin see *metadata* (name/host/user)
  for every saved VPS profile and revoke one — never the decrypted secret.
- Every deploy, uninstall, and admin config change is written to an
  append-only audit log (`/admin audit`), with password/token-shaped
  values redacted before they're stored.

## Before you point this at production infrastructure

This was built against the installer library's own documented
verification status, not assumed. Two things worth doing before relying
on it:

- Run a full deploy against a disposable VPS for each "ready" panel at
  least once — the scripts were written and reviewed carefully, but
  nothing here has been executed end-to-end in this environment (no
  outbound network access during development).
- Do not enable MythicalDash until `lib/mythicaldash/install.sh`'s own
  TODO is resolved — it's set to refuse to run (exit code 3) on purpose.
