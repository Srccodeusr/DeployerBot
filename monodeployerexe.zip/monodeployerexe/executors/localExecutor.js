// executors/localExecutor.js — runs lib/<panel>/install.sh in place on the
// same machine the bot runs on, via child_process. This is the "local"
// half of build brief section 5 ("support local and remote equally").

const { spawn } = require('node:child_process');
const readline = require('node:readline');
const { libPaths } = require('./executor');
const logger = require('../utils/logger').create('executor:local');

class LocalExecutor {
  // eslint-disable-next-line class-methods-use-this
  get type() {
    return 'local';
  }

  // No staging needed — the script already lives at its final relative
  // path next to lib/common/lib.sh inside this repo checkout.
  // eslint-disable-next-line class-methods-use-this
  async prepare() {}

  // eslint-disable-next-line class-methods-use-this
  async cleanup() {}

  // eslint-disable-next-line class-methods-use-this
  async disconnect() {}

  // eslint-disable-next-line class-methods-use-this
  describeTarget() {
    return 'this machine (local)';
  }

  /**
   * @returns {Promise<{exitCode: number}>}
   */
  // eslint-disable-next-line class-methods-use-this
  run(panelId, argv, { signal, timeoutMs, onLine }) {
    const { panelScript } = libPaths(panelId);

    return new Promise((resolve, reject) => {
      const child = spawn('bash', [panelScript, ...argv], {
        // A hosting panel installer needs root for package installs and
        // Docker — the operator running this bot is responsible for
        // running the bot process itself with appropriate privileges, or
        // for wiring in sudo out of band. We don't silently elevate here.
        stdio: ['ignore', 'pipe', 'pipe'],
      });

      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        onLine({ stream: 'stderr', line: `ERR: local execution timed out after ${timeoutMs}ms` });
        child.kill('SIGKILL');
      }, timeoutMs);

      const onAbort = () => {
        if (settled) return;
        child.kill('SIGKILL');
      };
      signal?.addEventListener('abort', onAbort, { once: true });

      const stdoutRl = readline.createInterface({ input: child.stdout });
      stdoutRl.on('line', (line) => onLine({ stream: 'stdout', line }));

      const stderrRl = readline.createInterface({ input: child.stderr });
      stderrRl.on('line', (line) => onLine({ stream: 'stderr', line }));

      child.on('error', (err) => {
        settled = true;
        clearTimeout(timer);
        signal?.removeEventListener('abort', onAbort);
        logger.error('failed to spawn installer', err);
        reject(err);
      });

      child.on('close', (code) => {
        settled = true;
        clearTimeout(timer);
        signal?.removeEventListener('abort', onAbort);
        resolve({ exitCode: code ?? -1 });
      });
    });
  }

  /**
   * Runs an arbitrary shell command (not one of the lib/<panel>/install.sh
   * scripts) — used for Cloudflare Tunnel install (build brief section 7),
   * `docker compose down -v` teardown (/uninstall), and reachability
   * checks (/status). Same line-by-line streaming and timeout handling as
   * run(), just without the install.sh-specific argv shape.
   * @returns {Promise<{exitCode: number}>}
   */
  // eslint-disable-next-line class-methods-use-this
  runRaw(command, { signal, timeoutMs, onLine } = {}) {
    return new Promise((resolve, reject) => {
      const child = spawn('bash', ['-c', command], { stdio: ['ignore', 'pipe', 'pipe'] });

      let settled = false;
      const timer = timeoutMs
        ? setTimeout(() => {
            if (settled) return;
            onLine?.({ stream: 'stderr', line: `ERR: command timed out after ${timeoutMs}ms` });
            child.kill('SIGKILL');
          }, timeoutMs)
        : null;

      const onAbort = () => {
        if (settled) return;
        child.kill('SIGKILL');
      };
      signal?.addEventListener('abort', onAbort, { once: true });

      const stdoutRl = readline.createInterface({ input: child.stdout });
      stdoutRl.on('line', (line) => onLine?.({ stream: 'stdout', line }));
      const stderrRl = readline.createInterface({ input: child.stderr });
      stderrRl.on('line', (line) => onLine?.({ stream: 'stderr', line }));

      child.on('error', (err) => {
        settled = true;
        if (timer) clearTimeout(timer);
        signal?.removeEventListener('abort', onAbort);
        reject(err);
      });
      child.on('close', (code) => {
        settled = true;
        if (timer) clearTimeout(timer);
        signal?.removeEventListener('abort', onAbort);
        resolve({ exitCode: code ?? -1 });
      });
    });
  }
}

module.exports = LocalExecutor;
