// executors/executor.js — the shared interface build brief section 2 asks
// for: "Abstract both [ssh2 and child_process] behind one shared executor
// interface so command code doesn't care which target it's running
// against." deploy/deployRunner.js is the only thing that talks to
// executors directly; commands/deployment/deploy.js only ever talks to
// deployRunner.
//
// Every executor implements:
//
//   async prepare(panelId) -> void
//     Stage lib/common/lib.sh + lib/<panelId>/install.sh wherever the
//     script is about to run. No-op for local (it already runs in place).
//     For remote, SFTPs both files into a fresh temp dir on the target.
//
//   async run(panelId, argv, { signal, timeoutMs, onLine }) -> { exitCode }
//     Invoke lib/<panelId>/install.sh with the given --key=value argv.
//     Calls onLine({ stream: 'stdout'|'stderr', line }) for every line as
//     it arrives, in order. Must respect `signal` (an AbortSignal) so
//     deployRunner can hard-abort on a PANEL_ID mismatch (build brief
//     section 6) without waiting for the process to finish on its own.
//     Must also enforce timeoutMs itself as a backstop even though every
//     script already wraps its own risky steps in run_with_timeout.
//
//   async cleanup() -> void
//     Remove any temp dir created in prepare(). No-op for local.
//
//   describeTarget() -> string
//     Human-readable target label for embeds/logs, e.g. "this machine" or
//     "203.0.113.10:22".

const path = require('node:path');

const LIB_DIR = path.join(__dirname, '..', 'lib');

function libPaths(panelId) {
  return {
    libDir: LIB_DIR,
    commonScript: path.join(LIB_DIR, 'common', 'lib.sh'),
    panelScript: path.join(LIB_DIR, panelId, 'install.sh'),
  };
}

/** Turns a flat { key: value } map into the ["--key=value", ...] argv the
 * install scripts require (they reject anything else — see
 * lib/common/lib.sh's parse_flags). Falsy/undefined values are omitted so
 * callers can pass a sparse object of only the flags the user actually
 * supplied. */
function buildArgv(flags) {
  return Object.entries(flags)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `--${k}=${v}`);
}

/**
 * @param {'local'|'remote'} targetType
 * @param {object} [remoteCreds] required when targetType === 'remote':
 *   { host, port, username, authMethod, secret, passphrase }
 */
function createExecutor(targetType, remoteCreds) {
  if (targetType === 'local') {
    // eslint-disable-next-line global-require
    const LocalExecutor = require('./localExecutor');
    return new LocalExecutor();
  }
  if (targetType === 'remote') {
    if (!remoteCreds) throw new Error('[executor] remote target requires credentials');
    // eslint-disable-next-line global-require
    const RemoteExecutor = require('./remoteExecutor');
    return new RemoteExecutor(remoteCreds);
  }
  throw new Error(`[executor] unknown target type: ${targetType}`);
}

module.exports = { createExecutor, buildArgv, libPaths };
