// executors/remoteExecutor.js — stages lib/common/lib.sh + the chosen
// lib/<panel>/install.sh onto a remote VPS over the same SSH session,
// then execs it there. This is the "remote" half of build brief section 5.
//
// Build brief section 2: "the executor abstraction needs to get the
// relevant lib/<panel>/install.sh plus lib/common/lib.sh onto the target
// over the same SSH session before invoking it (scp/SFTP the two files
// into a temp dir, run it, clean up after)."

const crypto = require('node:crypto');
const { Client } = require('ssh2');
const { libPaths } = require('./executor');
const config = require('../config/config');
const logger = require('../utils/logger').create('executor:remote');

class RemoteExecutor {
  /**
   * @param {object} creds { host, port, username, authMethod, secret, passphrase }
   *   authMethod is 'password' or 'private-key'; secret is the password or
   *   the private key PEM contents accordingly. Plaintext by the time it
   *   reaches here — decrypted just-in-time by the caller
   *   (deploy/deployRunner.js) right before connect(), never persisted
   *   outside vps_profiles' encrypted column.
   */
  constructor(creds) {
    this.creds = creds;
    this.conn = null;
    this.remoteTmpDir = null;
  }

  // eslint-disable-next-line class-methods-use-this
  get type() {
    return 'remote';
  }

  describeTarget() {
    return `${this.creds.host}:${this.creds.port ?? 22}`;
  }

  async _connect() {
    if (this.conn) return this.conn;
    this.conn = await new Promise((resolve, reject) => {
      const client = new Client();
      const connectConfig = {
        host: this.creds.host,
        port: this.creds.port ?? 22,
        username: this.creds.username,
        readyTimeout: config.execution.sshConnectTimeoutMs,
      };
      if (this.creds.authMethod === 'password') {
        connectConfig.password = this.creds.secret;
      } else {
        connectConfig.privateKey = this.creds.secret;
        if (this.creds.passphrase) connectConfig.passphrase = this.creds.passphrase;
      }
      client.on('ready', () => resolve(client));
      client.on('error', (err) => reject(err));
      client.connect(connectConfig);
    });
    return this.conn;
  }

  async prepare(panelId) {
    const conn = await this._connect();
    const { commonScript, panelScript } = libPaths(panelId);
    this.remoteTmpDir = `/tmp/monodeployerexe-${crypto.randomBytes(8).toString('hex')}`;

    await this._exec(conn, `mkdir -p ${this.remoteTmpDir}/common ${this.remoteTmpDir}/${panelId}`);

    const sftp = await new Promise((resolve, reject) => {
      conn.sftp((err, s) => (err ? reject(err) : resolve(s)));
    });

    await this._putFile(sftp, commonScript, `${this.remoteTmpDir}/common/lib.sh`);
    await this._putFile(sftp, panelScript, `${this.remoteTmpDir}/${panelId}/install.sh`);
    await this._exec(conn, `chmod +x ${this.remoteTmpDir}/${panelId}/install.sh`);

    logger.info(`staged installer for ${panelId} at ${this.remoteTmpDir} on ${this.describeTarget()}`);
  }

  // eslint-disable-next-line class-methods-use-this
  _putFile(sftp, localPath, remotePath) {
    return new Promise((resolve, reject) => {
      sftp.fastPut(localPath, remotePath, (err) => (err ? reject(err) : resolve()));
    });
  }

  // eslint-disable-next-line class-methods-use-this
  _exec(conn, command) {
    return new Promise((resolve, reject) => {
      conn.exec(command, (err, stream) => {
        if (err) return reject(err);
        let stderr = '';
        stream.on('close', (code) => (code === 0 ? resolve() : reject(new Error(stderr || `exit ${code}`))));
        stream.stderr.on('data', (d) => {
          stderr += d.toString();
        });
        return undefined;
      });
    });
  }

  /**
   * @returns {Promise<{exitCode: number}>}
   */
  async run(panelId, argv, { signal, timeoutMs, onLine }) {
    const conn = await this._connect();
    const remoteScript = `${this.remoteTmpDir}/${panelId}/install.sh`;
    const quotedArgv = argv.map((a) => `'${a.replace(/'/g, `'\\''`)}'`).join(' ');
    const command = `bash ${remoteScript} ${quotedArgv}`;

    return new Promise((resolve, reject) => {
      conn.exec(command, (err, stream) => {
        if (err) return reject(err);

        let settled = false;
        let stdoutBuf = '';
        let stderrBuf = '';

        const flushLines = (buf, stream_) => {
          const lines = buf.split('\n');
          const remainder = lines.pop();
          for (const line of lines) onLine({ stream: stream_, line });
          return remainder;
        };

        const timer = setTimeout(() => {
          if (settled) return;
          onLine({ stream: 'stderr', line: `ERR: remote execution timed out after ${timeoutMs}ms` });
          stream.close();
        }, timeoutMs);

        const onAbort = () => {
          if (settled) return;
          stream.close();
        };
        signal?.addEventListener('abort', onAbort, { once: true });

        stream.on('data', (data) => {
          stdoutBuf += data.toString();
          stdoutBuf = flushLines(stdoutBuf, 'stdout');
        });
        stream.stderr.on('data', (data) => {
          stderrBuf += data.toString();
          stderrBuf = flushLines(stderrBuf, 'stderr');
        });

        stream.on('close', (code) => {
          settled = true;
          clearTimeout(timer);
          signal?.removeEventListener('abort', onAbort);
          if (stdoutBuf) onLine({ stream: 'stdout', line: stdoutBuf });
          if (stderrBuf) onLine({ stream: 'stderr', line: stderrBuf });
          resolve({ exitCode: code ?? -1 });
        });

        stream.on('error', (streamErr) => {
          settled = true;
          clearTimeout(timer);
          signal?.removeEventListener('abort', onAbort);
          reject(streamErr);
        });
        return undefined;
      });
    });
  }

  /**
   * Runs an arbitrary shell command over the already-open SSH connection —
   * no lib/ staging involved. Used for Cloudflare Tunnel install (build
   * brief section 7), `docker compose down -v` teardown (/uninstall), and
   * reachability checks (/status).
   * @returns {Promise<{exitCode: number}>}
   */
  async runRaw(command, { signal, timeoutMs, onLine } = {}) {
    const conn = await this._connect();
    return new Promise((resolve, reject) => {
      conn.exec(command, (err, stream) => {
        if (err) return reject(err);

        let settled = false;
        let stdoutBuf = '';
        let stderrBuf = '';
        const flushLines = (buf, s) => {
          const lines = buf.split('\n');
          const remainder = lines.pop();
          for (const line of lines) onLine?.({ stream: s, line });
          return remainder;
        };

        const timer = timeoutMs
          ? setTimeout(() => {
              if (settled) return;
              onLine?.({ stream: 'stderr', line: `ERR: command timed out after ${timeoutMs}ms` });
              stream.close();
            }, timeoutMs)
          : null;

        const onAbort = () => {
          if (settled) return;
          stream.close();
        };
        signal?.addEventListener('abort', onAbort, { once: true });

        stream.on('data', (data) => {
          stdoutBuf += data.toString();
          stdoutBuf = flushLines(stdoutBuf, 'stdout');
        });
        stream.stderr.on('data', (data) => {
          stderrBuf += data.toString();
          stderrBuf = flushLines(stderrBuf, 'stderr');
        });
        stream.on('close', (code) => {
          settled = true;
          if (timer) clearTimeout(timer);
          signal?.removeEventListener('abort', onAbort);
          if (stdoutBuf) onLine?.({ stream: 'stdout', line: stdoutBuf });
          if (stderrBuf) onLine?.({ stream: 'stderr', line: stderrBuf });
          resolve({ exitCode: code ?? -1 });
        });
        stream.on('error', (streamErr) => {
          settled = true;
          if (timer) clearTimeout(timer);
          signal?.removeEventListener('abort', onAbort);
          reject(streamErr);
        });
        return undefined;
      });
    });
  }

  /** Called after prepare()+run() (the install.sh flow) — removes the
   * staged temp dir, then always disconnects. */
  async cleanup() {
    if (this.conn && this.remoteTmpDir) {
      try {
        await this._exec(this.conn, `rm -rf ${this.remoteTmpDir}`);
      } catch (err) {
        logger.warn(`failed to clean up remote temp dir ${this.remoteTmpDir}`, err.message);
      }
    }
    await this.disconnect();
  }

  /** Called after a runRaw()-only flow (tunnel install, uninstall,
   * /status live-check) that never staged a temp dir via prepare(). */
  async disconnect() {
    if (this.conn) {
      this.conn.end();
      this.conn = null;
    }
  }
}

module.exports = RemoteExecutor;
