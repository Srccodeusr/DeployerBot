// index.js — entry point. Slash-command/interaction-only bot, so it needs
// no privileged gateway intents beyond Guilds (interaction payloads
// already include member/role data without GuildMembers).

const { Client, GatewayIntentBits, Collection } = require('discord.js');
const config = require('./config/config');
const logger = require('./utils/logger').create('index');
const { loadCommands } = require('./handlers/commandHandler');
const { loadEvents } = require('./handlers/eventHandler');

// Side-effecting import: opens/creates the SQLite database and applies
// the schema before anything else runs.
require('./database/db');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.commands = new Collection();
for (const [name, command] of loadCommands()) client.commands.set(name, command);
logger.info(`loaded ${client.commands.size} command(s)`);

loadEvents(client);

process.on('unhandledRejection', (err) => logger.error('unhandled promise rejection', err));
process.on('uncaughtException', (err) => logger.error('uncaught exception', err));

client.login(config.discord.token);
