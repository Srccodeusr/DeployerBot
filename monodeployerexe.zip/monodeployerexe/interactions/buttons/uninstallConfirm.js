// interactions/buttons/uninstallConfirm.js — "uninstall:confirm:<deploymentId>".

const deployments = require('../../database/models/deployments');
const panelManifest = require('../../deploy/panelManifest');
const targetResolver = require('../../deploy/targetResolver');
const { buildUninstallCommand } = require('../../deploy/uninstallRunner');
const auditLog = require('../../database/models/auditLog');
const embeds = require('../../ui/embeds');
const { isBotAdmin } = require('../../utils/permissions');
const logger = require('../../utils/logger').create('uninstallConfirm');

module.exports = {
  customIdPrefix: 'uninstall:confirm',

  async execute(interaction) {
    const [, , deploymentIdRaw] = interaction.customId.split(':');
    const deploymentId = Number(deploymentIdRaw);
    const deployment = deployments.get(deploymentId);

    if (!deployment) {
      await interaction.update({ embeds: [embeds.danger({ title: 'Not found', description: 'That deployment record no longer exists.' })], components: [] });
      return;
    }
    if (deployment.user_id !== interaction.user.id && !isBotAdmin(interaction)) {
      await interaction.reply({ content: 'Only the person who ran this deployment (or a bot admin) can uninstall it.', ephemeral: true });
      return;
    }

    await interaction.update({ embeds: [embeds.accent({ title: 'Uninstalling\u2026', description: `Removing ${deployment.panel_id} from ${deployment.host_label}.` })], components: [] });

    const panel = panelManifest.byId(deployment.panel_id);
    const { command, verified } = buildUninstallCommand(deployment.panel_id, panel?.mode, deployment.install_dir);

    try {
      const { executor } = targetResolver.resolve(deployment.target_type, deployment.vps_profile_id);
      const { exitCode } = await executor.runRaw(command, { timeoutMs: 5 * 60 * 1000, onLine: () => {} });
      await executor.disconnect?.();

      auditLog.record({ guildId: deployment.guild_id, actorId: interaction.user.id, action: 'uninstall', target: deployment.panel_id, details: { deploymentId, exitCode } });

      if (exitCode === 0) {
        await interaction.editReply({
          embeds: [
            embeds.success({
              title: 'Uninstalled',
              description: `${panel?.display_name ?? deployment.panel_id} was removed from ${deployment.host_label}.${verified ? '' : ' Only the install directory was removed \u2014 double check for leftover services on that host.'}`,
            }),
          ],
        });
      } else {
        await interaction.editReply({ embeds: [embeds.warning({ title: 'Uninstall reported an issue', description: `The teardown command exited with code ${exitCode}. Some resources may remain \u2014 check the target directly.` })] });
      }
    } catch (err) {
      logger.error(`uninstall failed for deployment ${deploymentId}`, err);
      await interaction.editReply({ embeds: [embeds.danger({ title: 'Uninstall failed', description: err.message })] });
    }
  },
};
