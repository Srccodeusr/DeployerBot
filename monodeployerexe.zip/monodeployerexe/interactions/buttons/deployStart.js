// interactions/buttons/deployStart.js — "deploy:start:<token>". Runs the
// confirmed deployment end to end: resolve executor -> deployRunner ->
// stream progress -> persist history -> one-time secret reveal -> optional
// Cloudflare Tunnel install. Every attempt (success or failure) is
// recorded (build brief section 8).

const { buildArgv } = require('../../executors/executor');
const { runInstall } = require('../../deploy/deployRunner');
const { createProgressReporter } = require('../../deploy/progressReporter');
const { installTunnel } = require('../../deploy/tunnelInstaller');
const targetResolver = require('../../deploy/targetResolver');
const pendingDeployStore = require('../../deploy/pendingDeployStore');
const deployments = require('../../database/models/deployments');
const auditLog = require('../../database/models/auditLog');
const embeds = require('../../ui/embeds');
const components = require('../../ui/components');
const logger = require('../../utils/logger').create('deployStart');

function sanitizedFlagsForAudit(flags) {
  const out = {};
  for (const [k, v] of Object.entries(flags)) {
    out[k] = /password|token/i.test(k) ? '[redacted]' : v;
  }
  return out;
}

module.exports = {
  customIdPrefix: 'deploy:start',

  async execute(interaction) {
    const [, , token] = interaction.customId.split(':');
    const pending = pendingDeployStore.get(token);
    if (!pending) {
      await interaction.reply({ content: 'This deployment confirmation has expired — run `/deploy` again.', ephemeral: true });
      return;
    }
    pendingDeployStore.remove(token);

    let targetInfo;
    try {
      targetInfo = targetResolver.resolve(pending.target, pending.vpsProfileId);
    } catch (err) {
      await interaction.update({
        embeds: [embeds.danger({ title: 'Could not start deployment', description: err.message })],
        components: [],
      });
      return;
    }

    const deploymentId = deployments.start({
      guildId: pending.guildId,
      userId: pending.userId,
      channelId: pending.channelId,
      panelId: pending.panelId,
      targetType: pending.target,
      vpsProfileId: pending.vpsProfileId,
      hostLabel: targetInfo.label,
    });

    await interaction.update({
      embeds: [
        embeds.accent({
          title: `Deploying ${pending.panel.display_name} \u2192 ${targetInfo.label}`,
          description: 'Starting\u2026',
        }),
      ],
      components: [],
    });
    const message = await interaction.fetchReply();
    const reporter = createProgressReporter(message, { panelId: pending.panel.display_name, targetLabel: targetInfo.label });

    let outcome;
    try {
      outcome = await runInstall({
        executor: targetInfo.executor,
        panelId: pending.panelId,
        argv: buildArgv(pending.flags),
        deploymentId,
        onProgress: reporter.onProgress,
      });
    } catch (err) {
      logger.error(`deployment ${deploymentId} crashed`, err);
      outcome = { outcome: 'failed', exitCode: -1, message: err.message, logFile: null };
    }
    await reporter.finalize();

    auditLog.record({
      guildId: pending.guildId,
      actorId: pending.userId,
      action: 'deploy',
      target: pending.panelId,
      details: { target: pending.target, host: targetInfo.label, flags: sanitizedFlagsForAudit(pending.flags), outcome: outcome.outcome },
    });

    if (outcome.outcome === 'success') {
      const { result, warnings } = outcome;
      deployments.finishSuccess(deploymentId, {
        exitCode: outcome.exitCode,
        resultUrl: result.URL,
        resultAdminUser: result.ADMIN_USER,
        resultAdminPassword: result.ADMIN_PASSWORD,
        installDir: result.COMPOSE_DIR || result.INSTALL_DIR,
        logFile: outcome.logFile,
      });

      const fields = [];
      if (result.URL) fields.push({ name: 'URL', value: result.URL });
      if (result.ADMIN_USER) fields.push({ name: 'Admin user', value: result.ADMIN_USER, inline: true });
      if (result.ADMIN_PASSWORD) fields.push({ name: 'Admin password', value: 'Generated \u2014 click below to reveal once.', inline: true });
      if (result.ADMIN_SETUP === 'pending') fields.push({ name: 'Admin setup', value: 'Not automated for this panel \u2014 finish it manually (see /panels).' });
      if (!pending.cloudflareToken) {
        fields.push({
          name: 'Exposure',
          value: `Reachable directly at the target's address. Open the panel's port on the target's firewall to reach it externally, or run \`/tunnel\` later to front it with Cloudflare.`,
        });
      }
      if (warnings?.length) fields.push({ name: 'Warnings', value: warnings.map((w) => `\u2022 ${w}`).join('\n') });

      const rowComponents = result.ADMIN_PASSWORD ? [components.revealSecretRow({ deploymentId })] : [];

      await message.edit({
        embeds: [embeds.success({ title: `${pending.panel.display_name} deployed`, description: 'Deployment finished successfully.', fields })],
        components: rowComponents,
      });

      if (pending.cloudflareToken) {
        await message.reply({ embeds: [embeds.accent({ title: 'Installing Cloudflare Tunnel\u2026' })] });
        try {
          const tunnelResult = await installTunnel(targetInfo.executor, pending.cloudflareToken, { onLine: () => {} });
          deployments.recordTunnel(deploymentId, pending.cloudflareToken);
          await message.channel.send({
            embeds: [
              tunnelResult.exitCode === 0
                ? embeds.success({ title: 'Cloudflare Tunnel installed', description: 'Traffic will route through the tunnel you configured in Zero Trust.' })
                : embeds.warning({ title: 'Cloudflare Tunnel install had trouble', description: `cloudflared exited with code ${tunnelResult.exitCode}. The panel itself is still running \u2014 try \`/tunnel\` again.` }),
            ],
          });
        } catch (err) {
          logger.error(`tunnel install failed for deployment ${deploymentId}`, err);
          await message.channel.send({ embeds: [embeds.warning({ title: 'Cloudflare Tunnel install failed', description: 'The panel itself deployed fine \u2014 try `/tunnel` again separately.' })] });
        } finally {
          await targetInfo.executor.disconnect?.();
        }
      }
      return;
    }

    if (outcome.outcome === 'blocked') {
      deployments.finishFailure(deploymentId, { status: 'blocked', exitCode: outcome.exitCode, errorMessage: outcome.message, logFile: outcome.logFile });
      await message.edit({
        embeds: [
          embeds.warning({
            title: `${pending.panel.display_name} isn\u2019t available yet`,
            description: `This panel is blocked pending verification, not failed: ${outcome.message}`,
          }),
        ],
      });
      return;
    }

    if (outcome.outcome === 'routing_bug') {
      deployments.finishFailure(deploymentId, { status: 'aborted', exitCode: outcome.exitCode, errorMessage: outcome.message, logFile: outcome.logFile });
      await message.edit({
        embeds: [embeds.danger({ title: 'Deployment aborted \u2014 internal routing mismatch', description: outcome.message })],
      });
      logger.error(`PANEL_ID mismatch for deployment ${deploymentId} (requested ${pending.panelId})`);
      return;
    }

    deployments.finishFailure(deploymentId, { status: 'failed', exitCode: outcome.exitCode, errorMessage: outcome.message, logFile: outcome.logFile });
    await message.edit({
      embeds: [
        embeds.danger({
          title: `${pending.panel.display_name} deployment failed`,
          description: outcome.message,
          fields: [{ name: 'Next step', value: `Full log available via \`/logs deployment-id:${deploymentId}\`.` }],
        }),
      ],
    });
  },
};
