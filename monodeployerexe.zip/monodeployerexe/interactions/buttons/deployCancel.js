const pendingDeployStore = require('../../deploy/pendingDeployStore');
const embeds = require('../../ui/embeds');

module.exports = {
  customIdPrefix: 'deploy:cancel',

  async execute(interaction) {
    const [, , token] = interaction.customId.split(':');
    pendingDeployStore.remove(token);
    await interaction.update({
      embeds: [embeds.base({ title: 'Deployment cancelled', description: 'Nothing was run.' })],
      components: [],
    });
  },
};
