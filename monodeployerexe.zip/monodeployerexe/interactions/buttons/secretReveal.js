// interactions/buttons/secretReveal.js — "secret:reveal:<deploymentId>".
// Build brief section 8: show the generated admin password once, in the
// /deploy completion reply, then never again from /status or /logs.
// "Once" is enforced here too, not just by omission elsewhere — a second
// click on this same button after a successful reveal is refused.

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const deployments = require('../../database/models/deployments');
const auditLog = require('../../database/models/auditLog');
const embeds = require('../../ui/embeds');
const { isBotAdmin } = require('../../utils/permissions');

module.exports = {
  customIdPrefix: 'secret:reveal',

  async execute(interaction) {
    const [, , deploymentIdRaw] = interaction.customId.split(':');
    const deploymentId = Number(deploymentIdRaw);
    const deployment = deployments.get(deploymentId);

    if (!deployment) {
      await interaction.reply({ content: 'That deployment record no longer exists.', ephemeral: true });
      return;
    }
    if (deployment.user_id !== interaction.user.id && !isBotAdmin(interaction)) {
      await interaction.reply({ content: 'Only the person who ran this deployment (or a bot admin) can reveal its password.', ephemeral: true });
      return;
    }
    if (deployment.admin_password_revealed) {
      await interaction.reply({
        content: 'This password was already revealed once and won\u2019t be shown again here. Reset it through the panel\u2019s own admin tools if it\u2019s been lost.',
        ephemeral: true,
      });
      return;
    }

    const plaintext = deployments.decryptAdminPassword(deployment);
    deployments.markPasswordRevealed(deploymentId);
    auditLog.record({ guildId: deployment.guild_id, actorId: interaction.user.id, action: 'reveal_admin_password', target: String(deploymentId) });

    await interaction.reply({
      embeds: [embeds.accent({ title: 'Admin password', description: `\`\`\`${plaintext}\`\`\`\nThis is shown once and won\u2019t appear again \u2014 store it somewhere safe.` })],
      ephemeral: true,
    });

    // Disable the button on the original message so a second click isn't
    // even offered, on top of the server-side refusal above.
    const disabledRow = new ActionRowBuilder().addComponents(
      ButtonBuilder.from(interaction.message.components[0].components[0]).setDisabled(true).setLabel('Revealed'),
    );
    await interaction.message.edit({ components: [disabledRow] }).catch(() => {});
  },
};
