// interactions/buttons/deployAdvancedOpen.js — "deploy:advanced:<token>".
// Opens the modal that collects everything secret-shaped (admin password
// override, Cloudflare Tunnel token, mail credentials) so none of it is
// ever typed as a visible slash command option (build brief section 8).

const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const pendingDeployStore = require('../../deploy/pendingDeployStore');

module.exports = {
  customIdPrefix: 'deploy:advanced',

  async execute(interaction) {
    const [, , token] = interaction.customId.split(':');
    const pending = pendingDeployStore.get(token);
    if (!pending) {
      await interaction.reply({ content: 'This deployment confirmation has expired — run `/deploy` again.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder().setCustomId(`deploy:advancedSubmit:${token}`).setTitle('Advanced deploy options');

    const fields = [
      ['admin-password', 'Admin password override (blank = auto-generate)', false],
      ['cloudflare-token', 'Cloudflare Tunnel token (optional)', false],
      ['mail-host', 'SMTP host (optional)', false],
      ['mail-username', 'SMTP username (optional)', false],
      ['mail-password', 'SMTP password (optional)', false],
    ];

    modal.addComponents(
      ...fields.map(([id, label]) =>
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId(id)
            .setLabel(label)
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(pending.advancedFlags?.[id] ?? ''),
        ),
      ),
    );

    await interaction.showModal(modal);
  },
};
