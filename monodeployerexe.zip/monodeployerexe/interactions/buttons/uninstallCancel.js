const embeds = require('../../ui/embeds');

module.exports = {
  customIdPrefix: 'uninstall:cancel',

  async execute(interaction) {
    await interaction.update({ embeds: [embeds.base({ title: 'Uninstall cancelled', description: 'Nothing was changed.' })], components: [] });
  },
};
