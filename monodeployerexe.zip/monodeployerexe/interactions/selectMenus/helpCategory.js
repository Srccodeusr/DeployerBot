// interactions/selectMenus/helpCategory.js — handles the "help:category"
// select menu rendered by commands/utility/help.js.

const helpMenu = require('../../ui/helpMenu');

module.exports = {
  customIdPrefix: 'help:category',

  async execute(interaction) {
    const [selected] = interaction.values;
    await interaction.update({
      embeds: [helpMenu.categoryEmbed(selected)],
      components: [helpMenu.buildMenu(selected)],
    });
  },
};
