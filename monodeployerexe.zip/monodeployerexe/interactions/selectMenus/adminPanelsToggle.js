// interactions/selectMenus/adminPanelsToggle.js — "admin:panelsToggle",
// rendered by /admin panels. Re-checks isBotAdmin itself since a select
// menu interaction is a fresh interaction, not a continuation the
// original command's permission check still covers.

const guildConfig = require('../../database/models/guildConfig');
const auditLog = require('../../database/models/auditLog');
const embeds = require('../../ui/embeds');
const { isBotAdmin } = require('../../utils/permissions');

module.exports = {
  customIdPrefix: 'admin:panelsToggle',

  async execute(interaction) {
    if (!isBotAdmin(interaction)) {
      await interaction.reply({ content: 'This requires server admin, Manage Server, or the configured bot-admin role.', ephemeral: true });
      return;
    }
    guildConfig.setEnabledPanels(interaction.guildId, interaction.values);
    auditLog.record({ guildId: interaction.guildId, actorId: interaction.user.id, action: 'admin_set_panels', details: { enabled: interaction.values } });

    await interaction.update({
      embeds: [embeds.success({ title: 'Enabled panels updated', description: interaction.values.length ? interaction.values.map((v) => `\`${v}\``).join(', ') : 'None \u2014 `/deploy` will have nothing selectable until you enable at least one.' })],
      components: interaction.message.components,
    });
  },
};
