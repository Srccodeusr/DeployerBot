// interactions/modals/tunnelAddModal.js — "tunnel:addSubmit:<token>".
// Finishes /tunnel add: takes the Cloudflare token out of the modal and
// installs cloudflared on the deployment's original target.

const pendingTunnelStore = require('../../deploy/pendingTunnelStore');
const deployments = require('../../database/models/deployments');
const targetResolver = require('../../deploy/targetResolver');
const { installTunnel } = require('../../deploy/tunnelInstaller');
const embeds = require('../../ui/embeds');
const logger = require('../../utils/logger').create('tunnelAddModal');

module.exports = {
  customIdPrefix: 'tunnel:addSubmit',

  async execute(interaction) {
    const [, , token] = interaction.customId.split(':');
    const pending = pendingTunnelStore.get(token);
    if (!pending) {
      await interaction.reply({ content: 'This form expired \u2014 run `/tunnel add` again.', ephemeral: true });
      return;
    }
    pendingTunnelStore.remove(token);

    const cfToken = interaction.fields.getTextInputValue('token').trim();
    const deployment = deployments.get(pending.deploymentId);
    if (!deployment) {
      await interaction.reply({ content: 'That deployment record no longer exists.', ephemeral: true });
      return;
    }

    await interaction.deferReply({ ephemeral: true });
    try {
      const { executor } = targetResolver.resolve(deployment.target_type, deployment.vps_profile_id);
      const { exitCode } = await installTunnel(executor, cfToken, { onLine: () => {} });
      await executor.disconnect?.();
      if (exitCode === 0) {
        deployments.recordTunnel(deployment.id, cfToken);
        await interaction.editReply({ embeds: [embeds.success({ title: 'Cloudflare Tunnel installed', description: `Deployment #${deployment.id} is now routed through your tunnel.` })] });
      } else {
        await interaction.editReply({ embeds: [embeds.warning({ title: 'Install had trouble', description: `cloudflared exited with code ${exitCode}.` })] });
      }
    } catch (err) {
      logger.error(`tunnel add failed for deployment ${deployment.id}`, err);
      await interaction.editReply({ embeds: [embeds.danger({ title: 'Could not install tunnel', description: err.message })] });
    }
  },
};
