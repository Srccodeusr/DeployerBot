// interactions/modals/deployAdvancedModal.js — "deploy:advancedSubmit:<token>"
// Stores the submitted values back onto the pending deploy (in memory
// only, per deploy/pendingDeployStore.js) and re-renders the confirm
// embed. Nothing here is written to Discord as plain visible text beyond
// this ephemeral-context confirm screen the user themself is looking at.

const panelManifest = require('../../deploy/panelManifest');
const { buildFlagsForPanel } = require('../../deploy/flagBuilder');
const pendingDeployStore = require('../../deploy/pendingDeployStore');
const embeds = require('../../ui/embeds');
const components = require('../../ui/components');

module.exports = {
  customIdPrefix: 'deploy:advancedSubmit',

  async execute(interaction) {
    const [, , token] = interaction.customId.split(':');
    const pending = pendingDeployStore.get(token);
    if (!pending) {
      await interaction.reply({ content: 'This deployment confirmation has expired — run `/deploy` again.', ephemeral: true });
      return;
    }

    const adminPassword = interaction.fields.getTextInputValue('admin-password').trim();
    const cloudflareToken = interaction.fields.getTextInputValue('cloudflare-token').trim();
    const mailHost = interaction.fields.getTextInputValue('mail-host').trim();
    const mailUsername = interaction.fields.getTextInputValue('mail-username').trim();
    const mailPassword = interaction.fields.getTextInputValue('mail-password').trim();

    const advancedFlags = {
      'admin-password': adminPassword || undefined,
      'cloudflare-token': cloudflareToken || undefined,
      'mail-host': mailHost || undefined,
      'mail-username': mailUsername || undefined,
      'mail-password': mailPassword || undefined,
    };

    const { flags } = buildFlagsForPanel(pending.panelId, { ...pending.flags, ...advancedFlags });

    const updated = pendingDeployStore.update(token, {
      flags,
      advancedFlags,
      cloudflareToken: cloudflareToken || null,
    });

    const panel = panelManifest.byId(pending.panelId);
    const fields = [
      { name: 'Panel', value: panel.display_name, inline: true },
      { name: 'Target', value: pending.target === 'local' ? 'This machine' : pending.vpsProfileLabel, inline: true },
      { name: 'Mode', value: panel.mode, inline: true },
      {
        name: 'Flags',
        value:
          Object.entries(updated.flags)
            .map(([k, v]) => `\`--${k}=${k.includes('password') ? '\u2022'.repeat(6) : v}\``)
            .join(' ') || '(none set \u2014 panel defaults apply)',
      },
    ];
    if (updated.cloudflareToken) fields.push({ name: 'Cloudflare Tunnel', value: 'Token set \u2014 will be installed after the panel deploys.' });

    await interaction.update({
      embeds: [
        embeds.accent({
          title: 'Confirm deployment',
          description: 'Advanced options saved. Review and deploy when ready.',
          fields,
        }),
      ],
      components: [components.advancedOptionsRow({ token })],
    });
  },
};
