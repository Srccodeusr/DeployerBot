// interactions/modals/vpsAddModal.js — "vps:addSubmit:<token>". Finishes
// what commands/deployment/vps.js's "add" subcommand started: takes the
// secret out of the modal (never a slash option) and stores it encrypted.

const pendingVpsStore = require('../../deploy/pendingVpsStore');
const vpsProfiles = require('../../database/models/vpsProfiles');
const auditLog = require('../../database/models/auditLog');
const embeds = require('../../ui/embeds');

module.exports = {
  customIdPrefix: 'vps:addSubmit',

  async execute(interaction) {
    const [, , token] = interaction.customId.split(':');
    const pending = pendingVpsStore.get(token);
    if (!pending) {
      await interaction.reply({ content: 'This form expired \u2014 run `/vps add` again.', ephemeral: true });
      return;
    }
    pendingVpsStore.remove(token);

    const secret = interaction.fields.getTextInputValue('secret');
    let passphrase;
    try {
      passphrase = interaction.fields.getTextInputValue('passphrase');
    } catch {
      passphrase = undefined;
    }

    if (pending.authMethod === 'private-key' && !secret.includes('PRIVATE KEY')) {
      await interaction.reply({
        embeds: [embeds.danger({ title: 'Doesn\u2019t look like a private key', description: 'Paste the full PEM contents, including the `-----BEGIN ... PRIVATE KEY-----` lines.' })],
        ephemeral: true,
      });
      return;
    }

    vpsProfiles.create({
      guildId: pending.guildId,
      userId: pending.userId,
      name: pending.name,
      host: pending.host,
      port: pending.port,
      username: pending.username,
      authMethod: pending.authMethod,
      secret,
      passphrase: passphrase || undefined,
      createdBy: interaction.user.id,
    });

    auditLog.record({ guildId: pending.guildId, actorId: interaction.user.id, action: 'vps_add', target: pending.name, details: { host: pending.host, authMethod: pending.authMethod } });

    await interaction.reply({
      embeds: [embeds.success({ title: 'VPS profile saved', description: `\`${pending.name}\` (${pending.username}@${pending.host}:${pending.port}) is ready to use with \`/deploy target:remote\`.` })],
      ephemeral: true,
    });
  },
};
