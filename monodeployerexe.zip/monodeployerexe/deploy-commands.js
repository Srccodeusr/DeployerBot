// deploy-commands.js — standalone script (npm run deploy-commands) that
// registers every command's SlashCommandBuilder JSON with Discord's REST
// API. Run this once after adding/changing a command; it's separate from
// index.js because command registration is a one-off operation, not
// something that should happen on every bot restart.
//
// `npm run deploy-commands:guild` registers to DISCORD_DEV_GUILD_ID
// instead of globally — guild commands update instantly, global ones can
// take up to an hour to propagate, so use the guild target while
// developing.

const { REST, Routes } = require('discord.js');
const config = require('./config/config');
const { loadCommands } = require('./handlers/commandHandler');
const logger = require('./utils/logger').create('deploy-commands');

async function main() {
  const useGuild = process.argv.includes('--guild');
  const commands = [...loadCommands().values()].map((c) => c.data.toJSON());

  const rest = new REST().setToken(config.discord.token);

  if (useGuild) {
    if (!config.discord.devGuildId) {
      throw new Error('--guild was passed but DISCORD_DEV_GUILD_ID is not set in .env');
    }
    await rest.put(Routes.applicationGuildCommands(config.discord.clientId, config.discord.devGuildId), { body: commands });
    logger.info(`registered ${commands.length} command(s) to guild ${config.discord.devGuildId}`);
  } else {
    await rest.put(Routes.applicationCommands(config.discord.clientId), { body: commands });
    logger.info(`registered ${commands.length} command(s) globally (may take up to an hour to appear)`);
  }
}

main().catch((err) => {
  logger.error('failed to register commands', err);
  process.exitCode = 1;
});
